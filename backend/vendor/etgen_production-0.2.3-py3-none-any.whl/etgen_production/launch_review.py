"""Private launch-review packets from exact artifacts and explicit cost scenarios.

This does not approve products, change their cost facts, upload or publish.
Gallery HTML shows the real delivered previews, not generated product imagery.
"""
from __future__ import annotations

from html import escape
import hashlib
import json
from pathlib import Path
import shutil

from .artifacts import safe_file
from .models import fingerprint
from .costs import number, evaluate_cost, observed_cost_inputs


CSS = '''
@font-face{font-family:Review;src:url(assets/NotoSans-Regular.ttf)}
:root{--ink:#24463b;--muted:#547363;--paper:#faf9f5;--line:#d9dfd9}
*{box-sizing:border-box}body{margin:0;color:var(--ink);background:var(--paper);font-family:Review,system-ui,sans-serif}
h1,h2,h3,p{margin:0}h1{font-size:36px;line-height:1.15;max-width:24ch}h2{font-size:24px;line-height:1.25}h3{font-size:18px}
p,li{font-size:16px;line-height:1.6}p{max-width:68ch}a{color:inherit;text-underline-offset:4px}img{max-width:100%}
.eyebrow{font-size:14px;font-weight:700;letter-spacing:.09em;text-transform:uppercase;color:var(--muted)}
.muted{color:var(--muted)}.review{max-width:1120px;margin:auto;padding:48px 24px 80px}.review section{margin-top:48px}
.review h1{margin:16px 0 24px}.review p+p{margin-top:16px}.note{border-left:4px solid var(--ink);padding:16px 24px;background:#edf2ed}
table{border-collapse:collapse;width:100%;margin-top:24px;font-size:14px}td,th{border-bottom:1px solid var(--line);padding:12px;text-align:left;vertical-align:top}thead th{background:#edf2ed}.table-wrap{overflow:auto}
.gallery{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:24px;margin-top:24px}.gallery img{border:1px solid var(--line)}
.sheet{width:2400px;height:1800px;overflow:hidden;padding:112px 128px;position:relative;display:flex;flex-direction:column;gap:48px}
.sheet .eyebrow{font-size:28px}.sheet h1{font-size:104px;line-height:1.08;max-width:18ch}.sheet h2{font-size:72px;max-width:24ch}.sheet p,.sheet li{font-size:36px;line-height:1.5}
.sheet .body{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1fr);gap:96px;align-items:center;flex:1;min-height:0}
.sheet .body>div{min-width:0}.sheet ul{padding-left:40px;display:grid;gap:24px;margin-top:48px}.sheet .real-preview{height:1120px;width:100%;object-fit:contain;object-position:center;filter:drop-shadow(0 16px 24px #24463b18)}
.sheet .foot{display:flex;justify-content:space-between;border-top:2px solid var(--line);padding-top:24px;font-size:26px;color:var(--muted)}
.sheet>*{flex-shrink:0}.sheet .body,.sheet .pages{flex:1 1 0}
.pages{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));grid-auto-rows:minmax(0,1fr);gap:24px;min-height:0}.pages figure{margin:0;min-height:0;display:flex;flex-direction:column;gap:12px;align-items:center}.pages img{min-height:0;flex:1;object-fit:contain;width:100%;filter:drop-shadow(0 5px 10px #24463b12)}.pages figcaption{font-size:24px;color:var(--muted)}
.format{font-size:64px;font-weight:700;border-bottom:2px solid var(--line);padding:32px 0}.format small{display:block;font-size:32px;font-weight:400;color:var(--muted);margin-top:16px}.steps{display:grid;gap:48px;max-width:1700px;margin:48px 0}.steps h3{font-size:48px}.steps p{font-size:36px;margin-top:16px}
@media(max-width:600px){.review{padding:32px 16px}.review h1{font-size:28px}.gallery{grid-template-columns:1fr}}
'''


def document(title, content, *, gallery=False):
    return ('<!doctype html><html lang="en"><head><meta charset="utf-8">'
            '<meta name="viewport" content="width=device-width,initial-scale=1">'
            '<meta http-equiv="Content-Security-Policy" content="default-src \'none\'; img-src \'self\' data:; '
            'font-src \'self\'; style-src \'unsafe-inline\'; script-src \'none\'; connect-src \'none\'">'
            f'<title>{escape(title)}</title><style>{CSS}</style></head><body>'
            f'<main class="{"sheet" if gallery else "review"}">{content}</main></body></html>')


def display_assumption(key, value):
    value = number(value)
    if key.endswith('_fraction'):
        return f'{value * 100:g}%'
    if key.endswith('_usd'):
        return f'${value:.2f}'
    return f'{value:g}'


def prepare(job, artifact_root, destination, config):
    """Create a new review-only packet without changing live records/artifacts."""
    if job.get('status') not in ('needs_review', 'approved', 'exported'):
        raise ValueError('A technically completed revision is required')
    spec = job['spec']; result = job['result']; package = result['manifest']
    if config.get('country') != 'US':
        raise ValueError('This fee-basis model supports US sellers only')
    if spec.get('schema_version') != 2 or spec.get('family') not in ('wedding_workbook','wedding_binder'):
        raise ValueError('This launch packet supports the verified wedding product lines')
    if spec.get('delivery_kind') != 'instant_download' or result['quality']['status'] != 'passed':
        raise ValueError('A verified instant-download product is required')
    if package['spec_fingerprint'] != fingerprint(spec) or package['artifact_fingerprint'] != fingerprint(package['files']):
        raise ValueError('Specification or artifact fingerprint changed')
    artifact_root = Path(artifact_root).resolve(); destination = Path(destination).resolve()
    if destination.exists() or destination.is_relative_to(artifact_root):
        raise ValueError('Use a new review folder outside the immutable artifact folder')
    known = {row['name']: row for row in package['files']}
    for row in package['files']:
        path = safe_file(artifact_root, row['name'])
        if not path.is_file() or path.stat().st_size != row['bytes'] or hashlib.sha256(path.read_bytes()).hexdigest() != row['sha256']:
            raise ValueError('Actual artifact checksum changed')
    previews = package['render']['previews']
    if not 1 <= len(previews) <= 20 or any(name not in known or Path(name).suffix.lower() != '.png' for name in previews):
        raise ValueError('Real preview files are required')
    downloads = package['render'].get('download_files', ['customer.zip'])
    customer_roles = {'customer_file', 'customer_bundle', 'customer_download', 'customer_editable'}
    if not 1 <= len(downloads) <= 5 or any(name not in known or known[name]['role'] not in customer_roles or known[name]['bytes'] > 20*1024*1024 for name in downloads):
        raise ValueError('Customer downloads fail the verified file limits')
    scenarios = [{'name': item['name'], **evaluate_cost(spec['price'], config['fees'], item['assumptions'])}
                 for item in config['scenarios']]
    if not scenarios or any(row['status'] != 'illustrative_scenario' for row in scenarios):
        raise ValueError('Complete and label the planning scenarios before preparing the packet')
    from scripts.preserve_workspace import protect_directory
    protect_directory(destination)
    assets = destination/'assets'; assets.mkdir()
    for name in [*previews, 'NotoSans-Regular.ttf', 'font-license.txt']:
        if name not in known:
            raise ValueError('Verified preview font is missing')
        shutil.copy2(safe_file(artifact_root,name), assets/name)
    title = escape(spec['name']); workbook = spec['family'] == 'wedding_workbook'
    editable = 'XLSX' if workbook else 'PPTX'
    application = 'LibreOffice Calc' if workbook else 'LibreOffice Impress'
    page_names = (['Overview','Budget','Guests','Vendors','Timeline'] if workbook else
                  ['Cover','Essentials','Timeline','Suppliers','Setup','Ceremony','Reception','Guest comfort','Packing','Backup plan','Event close'])
    if len(page_names) != len(previews):
        raise ValueError('Actual preview count does not match the promised edition')
    foot = '<footer class="foot"><span>Digital download · No physical item</span><span>US Letter · AI-assisted design</span></footer>'
    real = lambda i: f'<img class="real-preview" src="assets/{escape(previews[i])}" alt="Actual {escape(page_names[i])} page">'
    bullets = lambda rows: '<ul>' + ''.join('<li>'+escape(row)+'</li>' for row in rows) + '</ul>'
    hero = (f'<p class="eyebrow">Wedding planning essentials</p><div class="body"><div><h1>{title}</h1>'
            f'<p style="margin-top:48px">Editable {editable} + printable PDF</p>'
            f'<p class="muted" style="margin-top:24px">{len(previews)} pages · Actual file previews shown</p></div><div>{real(0)}</div></div>{foot}')
    inside = (f'<p class="eyebrow">A look inside</p><h2>{"Five planning sheets" if workbook else "Ten fill-in pages and a cover"}</h2>'
              '<div class="pages">'+''.join(f'<figure><img src="assets/{escape(name)}" alt="Actual {escape(label)} page"><figcaption>{escape(label)}</figcaption></figure>' for name,label in zip(previews,page_names))+'</div>'+foot)
    features = (['Planned costs, confirmed amounts and payments','Balances and variance calculate from entered figures','Guest RSVP tracker and supplier details','200 working rows per schedule'] if workbook else
                ['Agreed timing, owners and contact details','Supplier handoffs, room setup and packing','Space for comfort needs and backup plans','Replaceable cover photo frame'])
    focus = f'<p class="eyebrow">Made for your own details</p><div class="body"><div><h2>{"See what is paid and what is still due" if workbook else "Keep the day’s handoff together"}</h2>{bullets(features)}</div><div>{real(1 if workbook else 2)}</div></div>{foot}'
    formats = (f'<p class="eyebrow">Your download</p><div class="body"><div><h2>Files you can edit.<br>Pages you can print.</h2>'
               f'<p style="margin-top:48px">Tested with the free {application} application and a PDF reader.</p>'
               '<p class="muted" style="margin-top:24px">An account connection or paid editing subscription is not required.</p></div><div>'
               f'<div class="format">{editable}<small>Editable {"workbook" if workbook else "presentation"}</small></div>'
               '<div class="format">PDF<small>US Letter print companion</small></div>'
               '<div class="format">ZIP<small>Files, instructions and included font license</small></div></div></div>'+foot)
    before = ['This is a blank planning template; add your own information.',
              'Digital files only. Printing and physical stationery are not included.',
              f'Editing was verified in {application}; other editors are not verified.',
              'The supplied PDF is static. Export a new PDF after editing.',
              'Created with AI assistance.']
    instructions = (f'<p class="eyebrow">Before you order</p><h2>Check the format.<br>Then make it yours.</h2><div class="steps">'
                    + ''.join(f'<div><p>{escape(item)}</p></div>' for item in before)+'</div>'+foot)
    pages = [('01-overview',hero),('02-inside',inside),('03-detail',focus),('04-files',formats),('05-before-ordering',instructions)]
    for name, content in pages:
        (destination/(name+'.html')).write_text(document(spec['name'],content,gallery=True),encoding='utf-8')
    listing = result['listing']
    if len(listing['title']) > 140 or len(listing['tags']) != 13 or len({t.casefold() for t in listing['tags']}) != 13 or any(not 2 <= len(t) <= 20 for t in listing['tags']):
        raise ValueError('Listing title or tags fail the platform bounds')
    report = {'schema_version':1,'purpose':'private_review_only','job_id':job['id'],'revision':job['revision'],
              'artifact_fingerprint':package['artifact_fingerprint'],'listing':listing,'scenarios':scenarios,
              'actual_total_variable_cost':spec.get('unit_cost'),'actual_cost_verified':False,
              'published_fee_sources':config['sources'],'seller_oauth':'not_verified_by_this_packet',
              'owner_approval_submitted':False,'publication_performed':False,
              'downloads':[{'name':name,'sha256':known[name]['sha256'],'bytes':known[name]['bytes']} for name in downloads],
              'gallery_pages':[name+'.html' for name,_ in pages], 'source_previews':previews,
              'automatic_product_imagery_generation':False}
    (destination/'listing-review.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    (destination/'listing-copy.txt').write_text(listing['title']+'\n\n'+listing['description']+'\n\nTags: '+', '.join(listing['tags']),encoding='utf-8')
    columns = ''.join('<th>'+escape(row['name'])+'</th>' for row in scenarios)
    cost_rows = ''.join('<tr><th>'+label+'</th>'+''.join(f'<td>${row[key]:.2f}</td>' for row in scenarios)+'</tr>'
                        for key,label in [('platform_fees','Base platform fees'),('support_labor','Support time allowance'),
                                          ('refund_allowance','Refund allowance'),('offsite_fee','Attributed-order advertising fee'),
                                          ('total_variable_cost','Scenario variable cost'),('contribution','Left before fixed costs and income tax')])
    assumption_rows = ''.join('<tr><th>'+label+'</th>'+''.join('<td>'+escape(display_assumption(key,row['assumptions'][key]))+'</td>' for row in scenarios)+'</tr>'
                             for key,label in [('support_contact_fraction','Share of orders needing help'),('support_minutes_per_contact','Minutes per support contact'),
                                               ('hourly_labor_usd','Value of one hour, USD'),('refund_revenue_fraction','Share of revenue reserved for refunds'),
                                               ('offsite_fee_fraction','Offsite fee on an attributed order'),('buyer_tax_usd','Buyer tax per scenario order, USD'),
                                               ('tax_on_seller_fees_usd','Tax on seller fees, USD'),('other_variable_usd','Other variable cost, USD')])
    content = (f'<p class="eyebrow">Private launch review · {escape(job["status"].replace("_"," "))}</p><h1>{title}</h1>'
               '<p class="note">Review only. No owner approval, upload or publication is performed by this packet. Actual all-in cost remains unverified.</p>'
               '<section><h2>Listing images</h2><p>These compositions show the actual generated pages. No substitute product image was generated.</p><div class="gallery">'
               + ''.join(f'<a href="{name}.html"><img src="{name}.png" alt="{escape(name)} listing image"></a>' for name,_ in pages)+'</div></section>'
               f'<section><h2>Pricing scenarios</h2><p>Proposed selling price: ${spec["price"]:.2f}. These are deliberately selected planning cases, not professional-seller benchmarks or measured costs. Zero tax and other-cost inputs are scenario assumptions, not verified exemptions.</p>'
               '<div class="table-wrap"><table><thead><tr><th>Per sale, USD</th>'+columns+'</tr></thead><tbody>'+cost_rows+'</tbody></table></div>'
               '<details style="margin-top:24px"><summary>See every assumption</summary><div class="table-wrap"><table><thead><tr><th>Planning input</th>'+columns+'</tr></thead><tbody>'+assumption_rows+'</tbody></table></div></details>'
               '<p style="margin-top:24px">Support allowance = fraction needing help × minutes per contact ÷ 60 × hourly value. Refund allowance = price × assumed refunded-revenue share. Offsite cases apply to attributed orders, not every order. Development, fixed overhead and income tax are separate. Fee refunds or credits may change the realized result.</p></section>'
               '<section><h2>Replace assumptions with measurements</h2><p>Record anonymous order keys, gross revenue, refunded revenue, support minutes (including explicit zero when no help was needed), and whether the refund observation window is complete. Divide support minutes by all orders. Measure refunded dollars against revenue for mature cohorts. Keep missing records unknown. Review after the first 10, 25 and 50 orders; those are operating checkpoints, not statistical proof.</p></section>'
               '<section><h2>Exact listing copy</h2><p><a href="listing-copy.txt">Open title, description and tags</a></p>'
               '<p style="margin-top:16px">This is the copy attached to the exact source revision. Any later edit requires a new reviewed revision.</p></section>'
               '<section><h2>Fee sources and pricing guidance</h2><ul>'
               + ''.join(f'<li><a href="{escape(source["url"],quote=True)}">{escape(source["title"])}</a></li>' for source in config['sources'])+'</ul></section>'
               f'<section><p class="muted">Source job {escape(job["id"])} · revision {escape(job["revision"][:12])}. All original artifacts remain unchanged.</p></section>')
    (destination/'index.html').write_text(document(spec['name'],content),encoding='utf-8')
    return report
