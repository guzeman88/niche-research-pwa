"""Honest renderer/delivery contracts shared by UI, listings and adapters."""
LEGACY_FAMILIES = ('planner', 'worksheet', 'wall_art', 'mug', 'apparel')
NEW_FAMILIES = ('birthday_magazine', 'birthday_newspaper', 'memory_book', 'party_set',
                'wedding_workbook', 'wedding_binder', 'bundle', 'tote',
                'pet_portrait', 'crochet_pattern')
DOCUMENT_FAMILIES = ('birthday_magazine', 'birthday_newspaper', 'memory_book', 'party_set', 'wedding_binder')


def delivery_kind(spec):
    if spec.get('schema_version', 1) == 2:
        return spec['delivery_kind']
    return 'physical' if spec['family'] in ('mug', 'apparel') else 'instant_download'


def is_physical(spec):
    return delivery_kind(spec) == 'physical'


def validate_capability(spec):
    family = spec['family']; kind = delivery_kind(spec)
    if family in ('mug', 'apparel', 'tote'):
        if kind != 'physical' or spec['size'] != 'provider':
            raise ValueError('Physical artwork requires physical delivery and exact provider dimensions')
    elif family != 'pet_portrait' and kind != 'instant_download':
        raise ValueError('This renderer supports instant-download delivery only')
    if family in DOCUMENT_FAMILIES + ('wedding_workbook', 'crochet_pattern', 'planner', 'worksheet', 'bundle') and spec['size'] not in ('letter', 'a4'):
        raise ValueError('Document products require Letter or A4')
    if family == 'pet_portrait' and spec['size'] not in ('8x10', '12x16', 'provider'):
        raise ValueError('Portraits require a supported print size')
    if any('canva' in str(app).casefold() for app in spec.get('compatibility', [])):
        raise ValueError('Canva customer-template delivery is not verified')
    if any(str(app).casefold() not in ('libreoffice impress', 'libreoffice calc', 'pdf reader') for app in spec.get('compatibility', [])):
        raise ValueError('The requested editable application has not been verified')
    if family in LEGACY_FAMILIES and (spec.get('compatibility') or 'editable' in spec['purpose'].casefold() or 'automatic calculations' in spec['purpose'].casefold()):
        raise ValueError('Legacy renderers do not provide editable customer documents or calculation')


def registry():
    records = []
    for family in LEGACY_FAMILIES + NEW_FAMILIES:
        record = {'family': family, 'implemented': True, 'human_review_required': True,
                  'provider_verified': False, 'commercially_evaluated': False,
                  'automatic_activation': False, 'paid_fallbacks': False}
        if family in DOCUMENT_FAMILIES:
            record.update(outputs=['pptx', 'pdf', 'zip'], prerequisite='Local office conversion and editing checks',
                          editable=True)
        elif family == 'wedding_workbook':
            record.update(outputs=['xlsx', 'pdf', 'zip'], prerequisite='Real local spreadsheet recalculation', editable=True)
        elif family in ('tote', 'mug', 'apparel'):
            record.update(outputs=['png'], prerequisite='Reviewed provider print area and physical sample', manufacturing_verified=False)
        elif family == 'pet_portrait':
            record.update(outputs=['pdf', 'png'], prerequisite='Original artwork or benchmarked local image workflow; likeness review', autonomous_image_verified=False)
        elif family == 'crochet_pattern':
            record.update(outputs=['pdf', 'zip'], prerequisite='Human-authored instructions and exact maker-test evidence')
        elif family == 'bundle':
            record.update(outputs=['zip'], prerequisite='Approved immutable component revisions')
        else:
            record.update(outputs=['pdf', 'zip'], prerequisite='Authored content and exact-file review')
        records.append(record)
    return records
