"""Explicit US planning costs and anonymized observed cost summaries."""
from decimal import Decimal, ROUND_HALF_UP
import hashlib
import json
from typing import Literal
from pydantic import BaseModel, ConfigDict, Field, field_validator


FEE_SCHEDULE = 'etsy-us-2026-11-13'
US_FEES = {'listing_usd': .20, 'transaction_fraction': .065,
           'payment_fraction': .03, 'payment_fixed_usd': .25}
FEE_SOURCES = ['https://www.etsy.com/legal/fees/',
               'https://help.etsy.com/hc/en-us/articles/115015628847-What-are-Payment-Processing-Fees-for-Selling-on-Etsy']


class ProvisionalCostPlan(BaseModel):
    model_config = ConfigDict(extra='forbid', str_strip_whitespace=True)
    country: Literal['US'] = 'US'
    currency: Literal['USD'] = 'USD'
    fee_schedule_id: Literal['etsy-us-2026-11-13'] = FEE_SCHEDULE
    support_contact_fraction: float = Field(ge=0,le=1,strict=True,allow_inf_nan=False)
    support_minutes_per_contact: float = Field(ge=0,le=600,strict=True,allow_inf_nan=False)
    hourly_labor_usd: float = Field(ge=0,le=10000,strict=True,allow_inf_nan=False)
    refund_revenue_fraction: float = Field(ge=0,le=1,strict=True,allow_inf_nan=False)
    offsite_fee_fraction: Literal[0,.12,.15]
    buyer_tax_usd: float = Field(ge=0,le=100000,strict=True,allow_inf_nan=False)
    tax_on_seller_fees_usd: float = Field(ge=0,le=100000,strict=True,allow_inf_nan=False)
    other_variable_usd: float = Field(ge=0,le=100000,strict=True,allow_inf_nan=False)
    assumptions_note: str = Field(min_length=20,max_length=1200)

    @field_validator('offsite_fee_fraction',mode='before')
    @classmethod
    def numeric_ad_case(cls,value):
        if isinstance(value,bool):raise ValueError('Choose an explicit numeric advertising fee case')
        return value


def estimate_plan(price, data):
    plan = ProvisionalCostPlan.model_validate(data).model_dump()
    result = evaluate_cost(price, US_FEES, plan)
    result.update(cost_basis='provisional',selling_price=float(number(price)),fee_schedule_id=FEE_SCHEDULE,
                  fee_sources=FEE_SOURCES,assumptions_note=plan['assumptions_note'],
                  plan_fingerprint=hashlib.sha256(json.dumps(plan,sort_keys=True,separators=(',',':')).encode()).hexdigest())
    return result

def number(value, *, maximum=None):
    if isinstance(value, bool):
        raise ValueError('A numeric amount is required')
    try:
        result = Decimal(str(value))
    except Exception as exc:
        raise ValueError('A numeric amount is required') from exc
    if not result.is_finite() or result < 0 or (maximum is not None and result > maximum):
        raise ValueError('Amount is outside the supported range')
    return result


def money(value):
    return number(value).quantize(Decimal('.01'), rounding=ROUND_HALF_UP)


def evaluate_cost(price, fees, assumptions):
    """One specified scenario, never an observed/actual total cost assertion."""
    price = number(price)
    required = ('support_contact_fraction', 'support_minutes_per_contact', 'hourly_labor_usd',
                'refund_revenue_fraction', 'offsite_fee_fraction', 'buyer_tax_usd',
                'tax_on_seller_fees_usd', 'other_variable_usd')
    missing = [key for key in required if assumptions.get(key) is None]
    if missing:
        return {'status': 'incomplete', 'missing': missing, 'total_variable_cost': None,
                'contribution': None, 'actual_cost_verified': False}
    values = {key: number(assumptions[key], maximum=1 if key.endswith('_fraction') else None)
              for key in required}
    transaction = money(price * number(fees['transaction_fraction'], maximum=1))
    processing = money((price + values['buyer_tax_usd']) * number(fees['payment_fraction'], maximum=1)
                       + number(fees['payment_fixed_usd']))
    platform = money(number(fees['listing_usd']) + transaction + processing)
    labor = money(values['support_contact_fraction'] * values['support_minutes_per_contact']
                  / Decimal(60) * values['hourly_labor_usd'])
    refund = money(price * values['refund_revenue_fraction'])
    # US seller model: buyer sales tax affects processing, not the item-price
    # basis used here for transaction/Offsite fees. No shipping for these files.
    offsite = money(price * values['offsite_fee_fraction'])
    total = platform + labor + refund + offsite + money(values['tax_on_seller_fees_usd']) + money(values['other_variable_usd'])
    # Contribution may be negative. Never clamp a loss to zero.
    contribution = (price - total).quantize(Decimal('.01'), rounding=ROUND_HALF_UP)
    return {'status': 'illustrative_scenario', 'actual_cost_verified': False,
            'platform_fees': float(platform), 'transaction_fee': float(transaction),
            'payment_fee': float(processing), 'support_labor': float(labor),
            'refund_allowance': float(refund), 'offsite_fee': float(offsite),
            'total_variable_cost': float(total), 'contribution': float(contribution),
            'assumptions': assumptions,
            'limits': ['Not measured seller history or guaranteed profit.',
                       'Refund allowance ignores possible fee reversals.',
                       'Development, fixed overhead and income taxes are separate.',
                       'Offsite fee case applies to an attributed order, not every order.']}


def observed_cost_inputs(orders):
    """Anonymized order measurements; missing values are never converted to zero."""
    if not orders:
        return {'orders': 0, 'support_minutes_per_order': None,
                'refunded_revenue_fraction': None, 'mature_refund_orders': 0}
    seen = set()
    for row in orders:
        key = row.get('order_key')
        if not isinstance(key, str) or not key or key in seen:
            raise ValueError('Each measured order needs a distinct opaque key')
        seen.add(key)
    support_complete = all(row.get('support_minutes') is not None for row in orders)
    support = (sum(number(row['support_minutes']) for row in orders) / len(orders)
               if support_complete else None)
    mature = [row for row in orders if row.get('refund_window_complete') is True]
    for row in mature:
        if row.get('gross_revenue') is not None and row.get('refunded_gross') is not None:
            if number(row['refunded_gross']) > number(row['gross_revenue']):
                raise ValueError('An order refund exceeds that order revenue')
    refund_complete = all(row.get('gross_revenue') is not None and row.get('refunded_gross') is not None for row in mature)
    revenue = sum((number(row['gross_revenue']) for row in mature), Decimal(0)) if refund_complete else Decimal(0)
    refunds = sum((number(row['refunded_gross']) for row in mature), Decimal(0)) if refund_complete else Decimal(0)
    if refunds > revenue:
        raise ValueError('Refunded revenue exceeds measured revenue')
    return {'orders': len(orders), 'support_minutes_per_order': float(support) if support is not None else None,
            'refunded_revenue_fraction': float(refunds / revenue) if revenue else None,
            'mature_refund_orders': len(mature)}


