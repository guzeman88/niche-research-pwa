"""Safe version-two file manifests; internal sources never become downloads."""
import hashlib
import mimetypes
from pathlib import Path, PurePosixPath
import zipfile
from .models import fingerprint
from .capabilities import is_physical


def safe_file(root, name):
    if not isinstance(name, str) or '\\' in name or ':' in name:
        raise ValueError('Unsafe artifact path')
    relative = PurePosixPath(name)
    if not name or relative.is_absolute() or any(p in ('', '.', '..') for p in relative.parts):
        raise ValueError('Unsafe artifact path')
    root = Path(root).resolve(); target = root.joinpath(*relative.parts)
    if not target.resolve().is_relative_to(root) or target.is_symlink():
        raise ValueError('Unsafe artifact path')
    return target


def manifest_v2(folder, result, spec):
    folder = Path(folder); files = []
    roles = result.get('roles', {})
    customers = set(result.get('customer_files', [])); previews = set(result.get('previews', [result.get('preview')]))
    intended = set(roles) | customers | previews | set(result.get('masters', []))
    for name in sorted(intended):
        path = safe_file(folder, name)
        if not path.is_file():
            raise ValueError('A promised artifact is missing: ' + name)
        role = roles.get(name, 'customer_file' if name in customers else 'preview' if name in previews else 'internal_source')
        files.append({'name': name, 'bytes': path.stat().st_size,
                      'sha256': hashlib.sha256(path.read_bytes()).hexdigest(), 'role': role,
                      'mime': mimetypes.guess_type(name)[0] or 'application/octet-stream'})
    known = {row['name'] for row in files}
    if not customers or not customers <= known or not previews <= known:
        raise ValueError('Renderer did not supply every promised customer file and preview')
    return {'schema_version': 2, 'spec_fingerprint': fingerprint(spec), 'render': result,
            'files': files, 'artifact_fingerprint': fingerprint(files),
            'dependencies': spec.get('product_data', {}).get('components', []),
            'license': 'See supplied asset/font provenance; no automatic rights clearance'}


def inspect_v2(folder, package, spec):
    checks = []; folder = Path(folder)
    names = [row['name'] for row in package['files']]
    checks.append({'check':'manifest_unique_files','passed':len(names)==len(set(names))})
    required = set(package['render'].get('customer_files',[])) | set(package['render'].get('previews',[]))
    checks.append({'check':'promised_files_present','passed':bool(required) and required <= set(names)})
    from .capabilities import DOCUMENT_FAMILIES
    family = spec['family']; customer_names = package['render'].get('customer_files',[])
    suffixes = {Path(name).suffix.lower() for name in customer_names}
    expected = ({'.pptx','.pdf'} if family in DOCUMENT_FAMILIES else
                {'.xlsx','.pdf'} if family == 'wedding_workbook' else
                {'.zip'} if family == 'bundle' else
                {'.png'} if is_physical(spec) else {'.pdf'})
    checks.append({'check':'required_customer_formats','passed':expected <= suffixes})
    for row in package['files']:
        target = safe_file(folder, row['name'])
        valid = target.is_file() and target.stat().st_size == row['bytes'] and hashlib.sha256(target.read_bytes()).hexdigest() == row['sha256']
        checks.append({'check': 'integrity:' + row['name'], 'passed': valid})
    if package['artifact_fingerprint'] != fingerprint(package['files']):
        checks.append({'check': 'manifest_fingerprint', 'passed': False})
    if package['spec_fingerprint'] != fingerprint(spec):
        checks.append({'check': 'spec_fingerprint', 'passed': False})
    if not all(row['passed'] for row in checks):
        return {'status': 'failed', 'checks': checks, 'visual_review': 'required', 'rights_review': 'required'}
    from .builders import inspect_v2 as inspect_builder
    extra = inspect_builder(folder, package['render'], spec)
    checks.extend(extra.get('checks', []))
    # Recheck archive paths and prevent internal-only files in distributed ZIPs.
    permitted = set(package['render'].get('customer_files', []))
    archive_members = set(); archives = []
    for name in permitted:
        target = safe_file(folder, name)
        if target.suffix.lower() == '.zip':
            archives.append(name)
            with zipfile.ZipFile(target) as archive:
                names = archive.namelist()
                valid = len(names) <= 200 and len(names) == len(set(names))
                valid = valid and sum(info.file_size for info in archive.infolist()) <= 200_000_000
                for member in names:
                    safe_file(folder, member)
                    if member not in permitted:
                        valid = False
                if valid:
                    for member in names:
                        if hashlib.sha256(archive.read(member)).hexdigest() != hashlib.sha256(safe_file(folder,member).read_bytes()).hexdigest():
                            valid = False
                    archive_members.update(names)
                checks.append({'check': 'customer_archive:' + name, 'passed': valid})
    if archives:
        checks.append({'check':'complete_customer_bundle','passed':archive_members == permitted-set(archives)})
    return {**extra, 'status': 'passed' if all(row['passed'] for row in checks) else 'failed',
            'checks': checks, 'visual_review': 'required', 'rights_review': 'required',
            'manufacturing': 'not_verified' if is_physical(spec) else 'not_applicable'}
