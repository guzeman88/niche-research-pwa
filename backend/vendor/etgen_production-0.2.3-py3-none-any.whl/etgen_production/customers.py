"""Private order instances. Customer data never enters catalog jobs or their mirror.

No source polling, messaging, automatic deletion, publishing or order purchases.
All methods are called behind the existing operator authorization boundary.
"""
from contextlib import closing
from copy import deepcopy
from datetime import datetime, timezone
from io import BytesIO
from pathlib import Path
import hashlib
import json
import re
import shutil
import sqlite3
import uuid

from PIL import Image, ImageOps

from .artwork import atomic
from .marketplace import lock
from .models import fingerprint


def _text(data, key, minimum=1, maximum=2000):
    value = data.get(key)
    if not isinstance(value, str) or not minimum <= len(value.strip()) <= maximum:
        raise ValueError(f'Supply {key.replace("_", " ")} ({minimum}–{maximum} characters)')
    if any(ord(c) < 32 and c not in '\n\t' for c in value):
        raise ValueError('Customer text contains control characters')
    return value.strip()


class CustomerStore:
    def __init__(self, engine):
        self.engine = engine
        self.root = engine.root / 'customers'

    def connect(self):
        self.root.mkdir(parents=True, exist_ok=True)
        con = sqlite3.connect(self.root / 'customers.sqlite', timeout=15)
        con.row_factory = sqlite3.Row
        con.execute('PRAGMA journal_mode=WAL')
        con.execute('PRAGMA synchronous=FULL')
        con.executescript('''
            CREATE TABLE IF NOT EXISTS instances(
              id TEXT PRIMARY KEY, identity TEXT UNIQUE NOT NULL, payload TEXT NOT NULL,
              status TEXT NOT NULL, result TEXT, created_at TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS customer_events(
              id INTEGER PRIMARY KEY, instance_id TEXT NOT NULL, action TEXT NOT NULL,
              payload TEXT NOT NULL, created_at TEXT NOT NULL);
        ''')
        return con

    @staticmethod
    def now():
        return datetime.now(timezone.utc).isoformat()

    @staticmethod
    def _id(instance_id):
        if not isinstance(instance_id, str) or not re.fullmatch(r'[0-9a-f]{32}', instance_id):
            raise ValueError('Invalid customer instance identifier')
        return instance_id

    def _event(self, con, instance_id, action, payload):
        con.execute('INSERT INTO customer_events(instance_id,action,payload,created_at) VALUES(?,?,?,?)',
                    (instance_id, action, json.dumps(payload, allow_nan=False), self.now()))

    def _template(self, product_id, revision, *, creating=False):
        with closing(self.engine.connect()) as con:
            row = con.execute('SELECT id FROM jobs WHERE product_id=? AND revision=?',
                              (product_id, revision)).fetchone()
        if not row:
            raise ValueError('The exact catalog product revision was not found')
        job = self.engine.job(row['id'])
        approval = (job.get('result') or {}).get('approval') or {}
        if approval.get('decision') != 'approve' or approval.get('revision') != revision:
            raise ValueError('Approve the exact catalog product before customer production')
        if creating and job['status'] not in ('approved', 'exported'):
            raise ValueError('New orders must select a currently approved product revision')
        if approval.get('artifact_fingerprint') != job['result']['manifest']['artifact_fingerprint']:
            raise ValueError('Catalog approval no longer matches its files')
        from .render import inspect
        quality = inspect(self.engine.root / 'artifacts' / job['id'],
                          job['result']['manifest'], job['spec'])
        if quality['status'] != 'passed':
            raise ValueError('Catalog files failed integrity verification')
        return job

    def create(self, data):
        if not isinstance(data, dict):
            raise ValueError('Supply an order instance object')
        allowed = {'source_order_id', 'line_item_id', 'product_id', 'revision', 'values',
                   'consent_note', 'creative_note', 'retention_note'}
        if set(data) - allowed:
            raise ValueError('Unexpected customer fields; do not upload complete order payloads')
        payload = {key: _text(data, key, 10 if key.endswith('_note') else 1,
                             2000 if key.endswith('_note') else 160)
                   for key in allowed - {'values'}}
        values = data.get('values', {})
        if not isinstance(values, dict) or len(values) > 20:
            raise ValueError('Supply at most twenty personalization fields')
        cleaned = {}
        for key, value in values.items():
            if not isinstance(key, str) or not re.fullmatch(r'[a-z][a-z0-9_]{0,39}', key):
                raise ValueError('Use simple named personalization fields')
            cleaned[key] = _text({key: value}, key, 1, 2000)
        if len(json.dumps(cleaned)) > 12000:
            raise ValueError('Personalization exceeds the supported size')
        payload['values'] = cleaned
        self._template(payload['product_id'], payload['revision'], creating=True)
        identity = fingerprint({key: payload[key] for key in
                                ('source_order_id', 'line_item_id', 'product_id', 'revision')})
        with closing(self.connect()) as con, con:
            con.execute('BEGIN IMMEDIATE')
            old = con.execute('SELECT id,payload FROM instances WHERE identity=?', (identity,)).fetchone()
            if old:
                if json.loads(old['payload']) != payload:
                    raise ValueError('Order inputs changed; preserve the existing instance and use a new line-item revision')
                return self.get(old['id'], connection=con)
            instance_id = uuid.uuid4().hex
            con.execute('INSERT INTO instances VALUES(?,?,?,?,?,?)',
                        (instance_id, identity, json.dumps(payload), 'needs_input', None, self.now()))
            self._event(con, instance_id, 'created', {'catalog_revision': payload['revision']})
            return self.get(instance_id, connection=con)

    def get(self, instance_id, connection=None):
        self._id(instance_id)
        own = connection is None
        con = connection or self.connect()
        try:
            row = con.execute('SELECT * FROM instances WHERE id=?', (instance_id,)).fetchone()
            if not row:
                raise ValueError('Customer instance not found')
            result = dict(row)
            result['payload'] = json.loads(result['payload'])
            result['result'] = json.loads(result['result']) if result['result'] else None
            result.pop('identity', None)
            result['history'] = [{**dict(r), 'payload': json.loads(r['payload'])} for r in con.execute(
                'SELECT action,payload,created_at FROM customer_events WHERE instance_id=? ORDER BY id', (instance_id,))]
            return result
        finally:
            if own:
                con.close()

    def list_instances(self):
        with closing(self.connect()) as con:
            # Listing views contain no customer names/order references/photo URLs.
            return [dict(r) for r in con.execute(
                'SELECT id,status,created_at FROM instances ORDER BY created_at DESC LIMIT 100')]

    def import_photo(self, instance_id, content, license_note, kind='reference'):
        self._id(instance_id)
        if kind not in ('reference', 'artwork'):
            raise ValueError('Photo kind must be reference or original artwork')
        if not isinstance(content, bytes) or len(content) > 20_000_000:
            raise ValueError('Image exceeds twenty MB')
        _text({'license_note': license_note}, 'license_note', 10)
        with lock(self.root / 'locks' / (instance_id + '.lock')):
            instance = self.get(instance_id)
            if instance['result'] or instance['status'] in ('approved', 'exported', 'cancelled'):
                raise ValueError('Create a revised instance before changing approved customer inputs')
            with Image.open(BytesIO(content)) as image:
                if image.width * image.height > 40_000_000:
                    raise ValueError('Image exceeds the local pixel limit')
                image.verify()
            photo_id = hashlib.sha256(content).hexdigest()[:24]
            folder = self.root / 'inputs' / instance_id
            folder.mkdir(parents=True, exist_ok=True)
            path = folder / (photo_id + '.png')
            if not path.exists():
                original = folder / (photo_id + '.source')
                if not original.exists():
                    original.write_bytes(content)
                with Image.open(BytesIO(content)) as image:
                    # Normalize orientation and exclude source metadata from derivatives.
                    normalized = ImageOps.exif_transpose(image).convert('RGBA')
                    normalized.save(path)
            receipt = {'photo_id': photo_id, 'file': path.name, 'kind': kind,
                       'sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
                       'license_note': license_note, 'identity_review_required': True}
            with closing(self.connect()) as con, con:
                self._event(con, instance_id, 'photo_imported', receipt)
                con.execute("UPDATE instances SET status='needs_input',result=NULL WHERE id=?", (instance_id,))
            return receipt

    def produce(self, instance_id):
        self._id(instance_id)
        with lock(self.engine.root / 'locks' / 'render-capacity.lock'), lock(self.root / 'locks' / (instance_id + '.lock')):
            instance = self.get(instance_id)
            if instance['status'] == 'cancelled':
                raise ValueError('Cancelled customer production cannot continue')
            if instance['result']:
                self._verify(instance)
                return instance
            data = instance['payload']
            template = self._template(data['product_id'], data['revision'])
            spec = deepcopy(template['spec'])
            values = data['values']
            fields = (spec.get('product_data') or {}).get('personalization_fields',
                      ['name', 'pet_name', 'recipient', 'date', 'age', 'caption', 'role', 'occasion_date'])
            if set(values) - set(fields):
                raise ValueError('Personalization contains fields not supported by this product')
            required = (spec.get('product_data') or {}).get('required_fields', [])
            if any(key not in values for key in required):
                raise ValueError('Supply all required personalization fields')
            def replace(value):
                if isinstance(value, str):
                    return re.sub(r'\{([a-z][a-z0-9_]*)\}',
                                  lambda match: values.get(match.group(1), match.group(0)), value)
                if isinstance(value, list):
                    return [replace(v) for v in value]
                if isinstance(value, dict):
                    return {k: replace(v) for k, v in value.items()}
                return value
            spec['content'] = replace(spec['content'])
            spec['personalization'] = ' · '.join(values.values())
            if spec.get('schema_version') == 2:
                spec['product_data'] = replace(spec.get('product_data', {}))
                spec['product_data'].update(values)
                if spec['family']=='pet_portrait' and 'name' in values and 'pet_name' not in values:
                    spec['product_data']['pet_name']=values['name']
                if 'age' in values:
                    if not values['age'].isdigit() or not 1 <= int(values['age']) <= 120:
                        raise ValueError('Age must be between one and 120')
                    spec['product_data']['age'] = int(values['age'])
                spec['creative_note'] = data['creative_note']
            if re.search(r'\{[a-z][a-z0-9_]*\}', json.dumps([spec['content'], spec.get('product_data', {})])):
                raise ValueError('Supply values for every remaining personalization placeholder')
            from .models import parse_spec
            spec = parse_spec(spec)
            artwork = None
            for event in instance['history']:
                if event['action'] == 'photo_imported':
                    item = event['payload']
                    path = self.root / 'inputs' / instance_id / item['file']
                    if hashlib.sha256(path.read_bytes()).hexdigest() != item['sha256']:
                        raise ValueError('Customer image changed; preserve and reconcile it')
                    if item['kind'] == 'artwork' or spec['family'] in ('birthday_magazine','birthday_newspaper','memory_book','party_set'):
                        artwork = path
            if spec['family'] == 'pet_portrait' and artwork is None:
                raise ValueError('Import original portrait artwork; reference photos alone do not establish a verified likeness workflow')
            if artwork is None and spec.get('artwork_id'):
                with closing(self.engine.connect()) as con:
                    row = con.execute('SELECT payload FROM assets WHERE id=?', (spec['artwork_id'],)).fetchone()
                if row:
                    asset = json.loads(row[0])
                    artwork = self.engine.root / 'assets' / asset['file']
                    if fingerprint(artwork.read_bytes().hex()) != asset['fingerprint']:
                        raise ValueError('Catalog artwork changed')
            from .render import render, manifest, inspect
            folder = self.root / 'artifacts' / instance_id
            if folder.exists():
                # Recover a crash after the atomic artifact commit but before the
                # SQLite result commit. Never overwrite a different partial set.
                if not (folder / 'manifest.json').is_file():
                    raise ValueError('Existing customer output needs reconciliation')
                package = json.loads((folder / 'manifest.json').read_text())
                if package.get('spec_fingerprint') != fingerprint(spec):
                    raise ValueError('Existing customer output belongs to different inputs')
                quality = inspect(folder, package, spec)
            else:
                attempt = self.root / 'attempts' / instance_id / uuid.uuid4().hex
                generated = render(spec, attempt, artwork)
                package = manifest(attempt, generated, spec)
                quality = inspect(attempt, package, spec)
                if quality['status'] != 'passed':
                    raise ValueError('Customer files failed technical verification')
                atomic(attempt / 'manifest.json', package)
                folder.parent.mkdir(parents=True, exist_ok=True)
                attempt.rename(folder)
            if quality['status'] != 'passed':
                raise ValueError('Customer files failed technical verification')
            result = {'manifest': package, 'quality': quality, 'spec': spec,
                      'approval': None, 'delivery_status': 'manual_delivery_required',
                      'publication_performed': False, 'order_placed': False}
            with closing(self.connect()) as con, con:
                con.execute("UPDATE instances SET status='needs_review',result=? WHERE id=?",
                            (json.dumps(result), instance_id))
                self._event(con, instance_id, 'produced', {'artifact_fingerprint': package['artifact_fingerprint']})
            return self.get(instance_id)

    def _verify(self, instance):
        if not instance['result']:
            raise ValueError('Customer files are not ready')
        from .render import inspect
        result = instance['result']
        folder = self.root / 'artifacts' / instance['id']
        if inspect(folder, result['manifest'], result['spec'])['status'] != 'passed':
            raise ValueError('Customer artifact integrity failed')
        return folder

    def review_proof(self, instance_id, data):
        self._id(instance_id)
        with lock(self.root / 'locks' / (instance_id + '.lock')):
            instance = self.get(instance_id)
            if instance['status'] != 'needs_review':
                raise ValueError('This customer proof is not awaiting review')
            self._verify(instance)
            result = instance['result']
            if data.get('artifact_fingerprint') != result['manifest']['artifact_fingerprint']:
                raise ValueError('Customer proof files changed')
            decision = data.get('decision')
            if decision not in ('approve', 'reject'):
                raise ValueError('Choose approve or reject')
            _text(data, 'note', 10)
            if decision == 'approve' and any((data.get('checks') or {}).get(k) is not True
                                            for k in ('identity', 'files', 'rights')):
                raise ValueError('Review customer identity, actual files and rights')
            result['approval'] = {k: data[k] for k in ('artifact_fingerprint', 'decision', 'note')}
            with closing(self.connect()) as con, con:
                con.execute('UPDATE instances SET status=?,result=? WHERE id=?',
                            ('approved' if decision == 'approve' else 'rejected', json.dumps(result), instance_id))
                self._event(con, instance_id, 'proof_' + decision, {'artifact_fingerprint': data['artifact_fingerprint']})
            return self.get(instance_id)

    def file(self, instance_id, name):
        instance = self.get(instance_id)
        folder = self._verify(instance)
        records = instance['result']['manifest']['files']
        if name not in {r['name'] for r in records}:
            raise ValueError('Unknown customer artifact')
        path = folder / name
        if not path.resolve().is_relative_to(folder.resolve()) or path.is_symlink():
            raise ValueError('Unsafe customer artifact')
        return path

    def export(self, instance_id):
        self._id(instance_id)
        with lock(self.root / 'locks' / (instance_id + '.lock')):
            instance = self.get(instance_id)
            if instance['status'] not in ('approved', 'exported'):
                raise ValueError('Approve the exact customer proof before export')
            self._verify(instance)
            folder = self.root / 'exports' / instance_id
            folder.mkdir(parents=True, exist_ok=True)
            for name in instance['result']['manifest']['render']['customer_files']:
                source = self.file(instance_id, name)
                target = folder / name
                target.parent.mkdir(parents=True, exist_ok=True)
                if target.exists():
                    if target.read_bytes() != source.read_bytes():
                        raise ValueError('Customer export differs; preserve and reconcile it')
                else:
                    shutil.copyfile(source, target)
            receipt = {'instance_id': instance_id, 'product_revision': instance['payload']['revision'],
                       'artifact_fingerprint': instance['result']['manifest']['artifact_fingerprint'],
                       'delivery_status': 'manual_delivery_required', 'order_placed': False}
            atomic(folder / 'receipt.json', receipt)
            with closing(self.connect()) as con, con:
                con.execute("UPDATE instances SET status='exported' WHERE id=?", (instance_id,))
                self._event(con, instance_id, 'exported', receipt)
            return receipt

    def cancel(self, instance_id):
        self._id(instance_id)
        with lock(self.root / 'locks' / (instance_id + '.lock')):
            instance = self.get(instance_id)
            if instance['status'] in ('approved', 'exported'):
                raise ValueError('Approved or exported files require explicit reconciliation')
            with closing(self.connect()) as con, con:
                con.execute("UPDATE instances SET status='cancelled' WHERE id=?", (instance_id,))
                self._event(con, instance_id, 'cancelled', {})
            return self.get(instance_id)

    def revise(self, instance_id, data):
        """Explicitly revise inputs; ordinary order reimports never duplicate work."""
        self._id(instance_id)
        if not isinstance(data, dict) or set(data) - {'values', 'creative_note'}:
            raise ValueError('Supply revised values and an individual creative note')
        with lock(self.root / 'locks' / (instance_id + '.lock')):
            old = self.get(instance_id)
            payload = deepcopy(old['payload'])
            values = data.get('values')
            if not isinstance(values, dict) or len(values) > 20:
                raise ValueError('Supply at most twenty revised fields')
            if any(not re.fullmatch(r'[a-z][a-z0-9_]{0,39}', str(k)) for k in values):
                raise ValueError('Invalid personalization field')
            payload['values'] = {k: _text({k: v}, k, 1, 2000) for k, v in values.items()}
            if len(json.dumps(payload['values'])) > 12000:
                raise ValueError('Personalization exceeds the supported size')
            payload['creative_note'] = _text(data, 'creative_note', 10)
            identity = fingerprint({'parent': instance_id, 'payload': payload})
            with closing(self.connect()) as con, con:
                existing = con.execute('SELECT id FROM instances WHERE identity=?', (identity,)).fetchone()
                if existing:
                    return self.get(existing['id'], connection=con)
                new_id = uuid.uuid4().hex
                con.execute('INSERT INTO instances VALUES(?,?,?,?,?,?)',
                            (new_id, identity, json.dumps(payload), 'needs_input', None, self.now()))
                self._event(con, new_id, 'revised_from', {'instance_id': instance_id})
                self._event(con, instance_id, 'revision_created', {'instance_id': new_id})
                # Deliberately reimport images; a customer identity change must not
                # silently reuse the previous customer's portrait/photo references.
                return self.get(new_id, connection=con)
