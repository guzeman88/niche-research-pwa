"""Editable starting briefs, never approved products or demand qualification."""
from copy import deepcopy


PRODUCTS = (
    ('birthday_magazine','Birthday magazine','birthday magazine template',
     ['Cover','A year to remember','Messages from friends','Favorite memories']),
    ('birthday_newspaper','Milestone birthday newspaper','birthday newspaper template',
     ['Birthday edition','The story so far','Memorable moments']),
    ('memory_book','Photo memory book','photo memory book template',
     ['Our memories','A favorite day','People we love','Looking ahead']),
    ('party_set','Coordinated birthday party set','birthday party printable set',
     ['Invitation','Welcome sign','Gift tags']),
    ('wedding_workbook','Wedding budget and guest workbook','wedding planning spreadsheet',
     ['Budget','Guests','Vendors','Timeline']),
    ('wedding_binder','Wedding-day coordination binder','wedding day binder',
     ['Wedding-day timeline','Vendor contacts','Setup checklist','Packing checklist']),
    ('bundle','Complete wedding planning suite','wedding planning bundle',
     ['Budget and guest workbook','Wedding-day coordination binder']),
)


def recipes():
    results=[]
    for family,name,keyword,content in PRODUCTS:
        spec={'schema_version':2,'name':name,'keyword':keyword,
              'buyer':'People creating a personal birthday keepsake' if family.startswith('birthday') or family in ('memory_book','party_set') else 'Couples coordinating their wedding',
              'purpose':'Create an original, useful '+name.lower()+' with the included editable fields and verified customer files.',
              'family':family,'content':content,'size':'letter','palette':'ink','layout':'editorial',
              'personalization':'','price':None,'unit_cost':None,'delivery':'','materials':'',
              'category_id':None,'rights_note':'','tags':[],'supporting_keywords':[],
              'provider':{},'research':{},'artwork_id':None,'concept_method':'authored',
              'artwork_method':'template','image_profile':'','delivery_kind':'instant_download',
              'creative_note':'','instructions':'','compatibility':[],
              'product_data':{'pages':[{'title':text,'body':''} for text in content]}}
        if family=='bundle':spec['product_data']={'components':[]}
        results.append({'id':family,'collection':'Birthday keepsakes' if family in ('birthday_magazine','birthday_newspaper','memory_book','party_set') else 'Wedding planning',
                        'name':name,'spec':deepcopy(spec), 'review_required':True})
    return results


def launch_recipes():
    return recipes()
