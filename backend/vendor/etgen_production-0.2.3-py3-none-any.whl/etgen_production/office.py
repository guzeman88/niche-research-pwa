"""Bounded, isolated free office conversion; no user office session is reused."""
from pathlib import Path
import os
import shutil
import subprocess
import uuid
import signal
import json
import tempfile
import zipfile
from xml.etree import ElementTree
from contextlib import contextmanager


@contextmanager
def bundled_fonts():
    """Temporarily register only our licensed font; no registry/install mutation."""
    font=Path(__file__).parent/'fonts/NotoSans-Regular.ttf'
    registered=False;gdi=None
    if os.name=='nt':
        import ctypes
        from ctypes import wintypes
        gdi=ctypes.WinDLL('gdi32',use_last_error=True)
        gdi.AddFontResourceExW.argtypes=[wintypes.LPCWSTR,wintypes.DWORD,ctypes.c_void_p]
        gdi.AddFontResourceExW.restype=ctypes.c_int
        gdi.RemoveFontResourceExW.argtypes=[wintypes.LPCWSTR,wintypes.DWORD,ctypes.c_void_p]
        gdi.RemoveFontResourceExW.restype=wintypes.BOOL
        registered=bool(gdi.AddFontResourceExW(str(font),0,None))
        if not registered:raise ValueError('The bundled production font could not be loaded for office rendering')
    try:yield
    finally:
        if registered:gdi.RemoveFontResourceExW(str(font),0,None)


def executable():
    candidates = [os.getenv('PRODUCTION_SOFFICE_PATH'), Path.home() / 'EtGen/tools/libreoffice-26.8.2/program/soffice.com', shutil.which('soffice'),
                  r'C:\Program Files\LibreOffice\program\soffice.com',
                  r'C:\Program Files\LibreOffice\program\soffice.exe']
    return next((str(Path(p).resolve()) for p in candidates if p and Path(p).is_file()), None)


def availability():
    path = executable()
    return {'available': bool(path), 'tool': 'LibreOffice', 'path': path,
            'paid_fallback': False, 'compatibility': ['LibreOffice'] if path else []}


def convert(source, output_dir, extension='pdf', timeout=120):
    source = Path(source).resolve(); output_dir = Path(output_dir).resolve()
    if extension not in ('pdf', 'xlsx', 'pptx', 'ods', 'odp'):
        raise ValueError('Unsupported office export format')
    binary = executable()
    if not binary:
        raise ValueError('LibreOffice is unavailable: configure PRODUCTION_SOFFICE_PATH before editable export or spreadsheet calculation')
    if not source.is_file() or source.suffix.lower() not in ('.pptx', '.xlsx', '.ods', '.odp'):
        raise ValueError('Choose a generated editable office document')
    if source.stat().st_size > 40_000_000:
        raise ValueError('Office input exceeds the production size limit')
    validate_generated_package(source)
    output_dir.mkdir(parents=True, exist_ok=True)
    # LibreOffice still creates deep Windows profile paths. Keep this profile in
    # the short system temp root rather than below a deeply nested artifact path.
    profile = Path(tempfile.mkdtemp(prefix='etgen-office-'))
    (profile / 'user').mkdir()
    (profile / 'user' / 'registrymodifications.xcu').write_text('''<?xml version="1.0" encoding="UTF-8"?>
<oor:items xmlns:oor="http://openoffice.org/2001/registry"><item oor:path="/org.openoffice.Office.Common/Security/Scripting"><prop oor:name="MacroSecurityLevel" oor:op="fuse"><value>3</value></prop></item><item oor:path="/org.openoffice.Office.Common/Load"><prop oor:name="UpdateDocMode" oor:op="fuse"><value>0</value></prop></item></oor:items>''', encoding='utf-8')
    cmd = [binary, '-env:UserInstallation=' + profile.as_uri(), '--headless',
           '--nologo', '--nodefault', '--norestore', '--convert-to', extension,
           '--outdir', str(output_dir), str(source)]
    kwargs = {'creationflags': subprocess.CREATE_NO_WINDOW} if os.name == 'nt' else {'start_new_session':True}
    try:
        # Font discovery is local to this child process; no user font installation.
        env = {**os.environ, 'SAL_FONTPATH': str(Path(__file__).parent / 'fonts')}
        with bundled_fonts():
            process = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=env, **kwargs)
            try:
                stdout,stderr=process.communicate(timeout=timeout)
            except subprocess.TimeoutExpired:
                # Terminate only this invocation's tree, not another user's office.
                if os.name=='nt':
                    subprocess.run(['taskkill','/PID',str(process.pid),'/T','/F'],capture_output=True,timeout=15)
                else:os.killpg(process.pid, signal.SIGKILL)
                process.communicate(timeout=15)
                raise
            completed=subprocess.CompletedProcess(cmd,process.returncode,stdout,stderr)
    except subprocess.TimeoutExpired as exc:
        raise ValueError('Office conversion exceeded its bounded processing time; attempt retained') from exc
    target = output_dir / (source.stem + '.' + extension)
    (output_dir / ('office-result-'+profile.name+'.json')).write_text(json.dumps({'returncode':completed.returncode,
        'profile':str(profile),
        'stdout':completed.stdout.decode(errors='replace')[:4000],
        'stderr':completed.stderr.decode(errors='replace')[:4000]},indent=2),encoding='utf-8')
    if completed.returncode != 0 or not target.is_file() or not target.stat().st_size:
        raise ValueError('Office conversion did not produce a valid output; attempt retained')
    # Only the exact newly created temporary tool profile is disposable. Failed
    # attempts and their profiles are retained; customer files are never removed.
    if profile.resolve().is_relative_to(Path(tempfile.gettempdir()).resolve()) and profile.name.startswith('etgen-office-'):
        try:shutil.rmtree(profile)
        except OSError:pass
    return target


def validate_generated_package(source):
    """Reject active/remote content even if a caller supplies an unexpected file."""
    try:
        with zipfile.ZipFile(source) as archive:
            records=archive.infolist()
            if len(records)>2000 or sum(r.file_size for r in records)>150_000_000:
                raise ValueError('Office package exceeds safe expansion limits')
            for record in records:
                name=record.filename.replace('\\','/')
                if name.startswith('/') or '..' in name.split('/') or any(x in name.lower() for x in ('vbaproject','activex','embeddings/')):
                    raise ValueError('Office package contains unsupported active content')
                if name.endswith('.rels'):
                    root=ElementTree.fromstring(archive.read(record))
                    if any(node.get('TargetMode','').lower()=='external' for node in root):
                        raise ValueError('Office package contains unsupported external links')
    except (zipfile.BadZipFile,ElementTree.ParseError) as exc:
        raise ValueError('Office package is malformed') from exc


def previews(pdf, folder):
    """Rasterize the actual final PDF, never an independent approximation."""
    import pypdfium2 as pdfium
    folder = Path(folder)
    names = []
    document = pdfium.PdfDocument(str(pdf))
    try:
        if not 1 <= len(document) <= 100:
            raise ValueError('Document page count exceeds production limits')
        for i in range(len(document)):
            name = 'preview.png' if i == 0 else f'preview-{i+1:03d}.png'
            page = document[i]
            try:
                bitmap = page.render(scale=1.25)
                image = bitmap.to_pil()
                image.save(folder / name)
                bitmap.close()
            finally:
                page.close()
            names.append(name)
    finally:
        document.close()
    return names
