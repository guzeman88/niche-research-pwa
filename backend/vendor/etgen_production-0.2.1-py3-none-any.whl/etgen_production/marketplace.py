"""Explicit, resumable unpublished-product and draft-only marketplace operations."""
import hashlib
import json
import os
from pathlib import Path
from contextlib import contextmanager
import time
import httpx
from urllib.parse import urlparse
from .artwork import atomic
from .providers import CapabilityError
from .models import fingerprint
from .capabilities import is_physical, delivery_kind


@contextmanager
def lock(path):
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('a+b') as stream:
        if stream.tell()==0:stream.write(b'0');stream.flush()
        stream.seek(0)
        try:
            if os.name=='nt':
                import msvcrt
                msvcrt.locking(stream.fileno(),msvcrt.LK_NBLCK,1)
            else:
                import fcntl
                fcntl.flock(stream.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB)
        except OSError as exc:raise ValueError('This external operation is already running') from exc
        try:yield
        finally:
            stream.seek(0)
            if os.name=='nt':msvcrt.locking(stream.fileno(),msvcrt.LK_UNLCK,1)
            else:fcntl.flock(stream.fileno(),fcntl.LOCK_UN)


def configured():
    return {'printify':bool(os.getenv('PRINTIFY_API_TOKEN') and os.getenv('PRINTIFY_SHOP_ID')),
            'etsy':bool(os.getenv('PRODUCTION_ETSY_SHOP_ID') and os.getenv('PRODUCTION_ETSY_ACCESS_TOKEN')
                        and os.getenv('ETSY_API_KEYSTRING') and os.getenv('ETSY_SHARED_SECRET')),
            'printful':'not_verified','gelato':'catalog_product_creation_unsupported',
            'activation':'disabled','orders':'disabled'}


def printify_mockups(engine,job_id):
    job=engine.job(job_id);s=job['spec'];selection=s['provider']
    if not is_physical(s):raise ValueError('Digital previews use the actual customer layout')
    if not configured()['printify']:raise CapabilityError('Configure a reviewed Printify token and shop first')
    required=('blueprint_id','print_provider_id','variant_ids','placement','retail_price_cents')
    if any(not selection.get(k) for k in required):raise ValueError('Select actual Printify catalog, variants, placement and price')
    if selection.get('artwork_reviewed') is not True:raise ValueError('Review the actual artwork before creating an unpublished provider product')
    area=engine.file(job_id,'artwork.png');folder=engine.root/'provider_receipts'/job_id;folder.mkdir(parents=True,exist_ok=True)
    url='https://api.printify.com/v1';headers={'Authorization':'Bearer '+os.environ['PRINTIFY_API_TOKEN']}
    shop=os.environ['PRINTIFY_SHOP_ID'];identity=fingerprint({'selection':selection,'art':hashlib.sha256(area.read_bytes()).hexdigest(),'shop':shop})
    receipt=folder/'printify.json'
    with lock(folder/'printify.lock'),httpx.Client(headers=headers,timeout=30) as client:
        saved=json.loads(receipt.read_text()) if receipt.exists() else {'identity':identity}
        if saved['identity']!=identity:raise ValueError('Provider inputs changed; create a revision')
        if saved.get('state')=='create_unknown':raise CapabilityError('Reconcile the unpublished provider product before retrying')
        r=client.get(url+f'/catalog/blueprints/{int(selection["blueprint_id"])}/print_providers/{int(selection["print_provider_id"])}/variants.json');r.raise_for_status()
        variants={v['id']:v for v in r.json().get('variants',[])}
        for variant in selection['variant_ids']:
            row=variants.get(int(variant))
            if not row:raise ValueError('Catalog variant is unavailable')
            places=[p for p in row.get('placeholders',[]) if p.get('position')==selection['placement']]
            if not places or any(p['width']>selection['width_px'] or p['height']>selection['height_px'] for p in places):
                raise ValueError('Artwork does not meet the actual selected catalog print area')
        if not saved.get('upload_id'):
            import base64
            r=client.post(url+'/uploads/images.json',json={'file_name':area.name,'contents':base64.b64encode(area.read_bytes()).decode()});r.raise_for_status()
            saved['upload_id']=r.json()['id'];atomic(receipt,saved)
        if not saved.get('product_id'):
            saved['state']='create_unknown';atomic(receipt,saved)
            payload={'title':s['name'],'description':s['purpose'],'blueprint_id':int(selection['blueprint_id']),
                     'print_provider_id':int(selection['print_provider_id']),
                     'variants':[{'id':int(v),'price':int(selection['retail_price_cents']),'is_enabled':True} for v in selection['variant_ids']],
                     'print_areas':[{'variant_ids':selection['variant_ids'],'placeholders':[{'position':selection['placement'],
                                    'images':[{'id':saved['upload_id'],'x':.5,'y':.5,'scale':1,'angle':0}]}]}]}
            r=client.post(url+f'/shops/{shop}/products.json',json=payload)
            if 400<=r.status_code<500 and r.status_code not in (408,409):saved['state']='rejected';atomic(receipt,saved)
            r.raise_for_status()
            saved.update(product_id=r.json()['id'],state='created_unpublished');atomic(receipt,saved)
        r=client.get(url+f'/shops/{shop}/products/{saved["product_id"]}.json');r.raise_for_status()
        # Keep provider images separate from the customer's immutable artifact manifest.
        images=r.json().get('images',[]);saved['images']=[{'src':i['src'],'variant_ids':i.get('variant_ids',[])} for i in images[:10]]
        atomic(receipt,saved)
        from PIL import Image
        artifact_folder=engine.root/'artifacts'/job_id
        names=[]
        for index,image in enumerate(saved['images']):
            parsed=urlparse(image['src'])
            if parsed.scheme!='https' or not parsed.hostname or not parsed.hostname.endswith('.printify.com'):
                raise ValueError('Provider mockup host is not a verified Printify image endpoint')
            if image['variant_ids'] and not set(map(int,image['variant_ids'])) & set(map(int,selection['variant_ids'])):continue
            target=artifact_folder/f'provider-mockup-{index+1:02d}.png'
            if not target.exists():
                response=httpx.get(image['src'],timeout=30);response.raise_for_status()
                if len(response.content)>20_000_000:raise ValueError('Provider mockup exceeds twenty MB')
                from io import BytesIO
                with Image.open(BytesIO(response.content)) as picture:
                    if picture.width*picture.height>40_000_000:raise ValueError('Provider mockup exceeds memory budget')
                    picture.convert('RGB').save(target)
            names.append(target.name)
        if names:engine.attach_mockups(job_id,names,{'product_id':saved['product_id'],'artwork_identity':identity})
        return {'state':saved['state'],'product_id':saved['product_id'],'images':saved['images'],
                'publication_performed':False,'order_placed':False,'review_required':True}


def etsy_draft(engine,job_id):
    job=engine.job(job_id)
    if job['status'] not in ('approved','exported'):raise ValueError('Approve the exact listing and customer files first')
    if delivery_kind(job['spec']) == 'made_to_order_digital':
        raise CapabilityError('Made-to-order digital platform delivery is not verified; use the reviewed local handoff')
    if not configured()['etsy']:raise CapabilityError('Configure reviewed seller OAuth and shop identity for draft creation')
    receipt=engine.root/'etsy_receipts'/job_id/'receipt.json';receipt.parent.mkdir(parents=True,exist_ok=True)
    shop=os.environ['PRODUCTION_ETSY_SHOP_ID'];token=os.environ['PRODUCTION_ETSY_ACCESS_TOKEN']
    headers={'Authorization':'Bearer '+token,'x-api-key':os.environ['ETSY_API_KEYSTRING']+':'+os.environ['ETSY_SHARED_SECRET']}
    url='https://openapi.etsy.com/v3';listing=job['result']['listing'];spec=job['spec']
    identity=fingerprint({'shop':shop,'revision':job['revision'],'artifacts':job['result']['manifest']['artifact_fingerprint']})
    with lock(receipt.with_suffix('.lock')),httpx.Client(headers=headers,timeout=30) as client:
        saved=json.loads(receipt.read_text()) if receipt.exists() else {'identity':identity,'images':{},'files':{}}
        if saved['identity']!=identity:raise ValueError('Seller or package changed; create a new revision')
        if saved.get('state')=='create_unknown':raise CapabilityError('Reconcile the uncertain Etsy draft before retrying')
        # Prevent writes to the other account's shop.
        r=client.get(url+'/application/users/me');r.raise_for_status();user=r.json()['user_id']
        r=client.get(url+f'/application/users/{user}/shops');r.raise_for_status()
        payload=r.json();shops=payload.get('results',[payload])
        if not any(str(row.get('shop_id'))==shop for row in shops):raise ValueError('OAuth seller does not own the selected shop')
        digital=not is_physical(spec)
        image_names=job['result']['manifest']['render'].get('previews',['preview.png'])[:10] if digital else job['result'].get('provider_mockups',[])
        if not image_names:raise CapabilityError('Create and review provider mockups before a physical Etsy draft')
        images=[engine.file(job_id,name,customer=True) for name in image_names]
        download_names=job['result']['manifest']['render'].get('download_files',['customer.zip'])
        if len(download_names)>5:raise ValueError('Package the customer files into at most five downloads')
        downloads=[engine.file(job_id,name,customer=True) for name in download_names] if digital else []
        if any(p.stat().st_size>20*1024*1024 for p in downloads):raise ValueError('Customer download exceeds twenty MB')
        if not saved.get('listing_id'):
            saved['state']='create_unknown';atomic(receipt,saved)
            data={'quantity':1,'title':listing['title'],'description':listing['description'],'price':listing['price'],
                  'who_made':'i_did','when_made':'made_to_order','taxonomy_id':listing['taxonomy_id'],'tags':listing['tags'],'type':'download' if digital else 'physical','state':'draft'}
            if not digital:data.update(shipping_profile_id=spec['provider']['shipping_profile_id'],readiness_state_id=spec['provider']['readiness_state_id'])
            r=client.post(url+f'/application/shops/{shop}/listings',data=data)
            if 400<=r.status_code<500 and r.status_code not in (408,409):saved['state']='rejected';atomic(receipt,saved)
            r.raise_for_status();saved.update(listing_id=r.json()['listing_id'],state='uploading');atomic(receipt,saved)
        endpoint=url+f'/application/shops/{shop}/listings/{saved["listing_id"]}'
        for rank,(path,kind) in enumerate([*[(p,'images') for p in images],*[(p,'files') for p in downloads]],start=1):
            digest=hashlib.sha256(path.read_bytes()).hexdigest()
            if digest in saved[kind]:continue
            # Content-derived name allows read reconciliation after an uncertain upload.
            name='etgen-'+digest[:24]+path.suffix
            existing=client.get(endpoint+'/'+kind);existing.raise_for_status()
            found=next((v for v in existing.json().get('results',[]) if v.get('filename')==name or (kind=='images' and v.get('alt_text')==name)),None)
            if found:saved[kind][digest]=found.get('listing_file_id') or found.get('listing_image_id');atomic(receipt,saved);continue
            with path.open('rb') as stream:
                r=client.post(endpoint+'/'+kind,data={'rank':rank,'name':name,'alt_text':name},files={('image' if kind=='images' else 'file'):(name,stream)})
            r.raise_for_status();saved[kind][digest]=r.json().get('listing_image_id') or r.json().get('listing_file_id');atomic(receipt,saved)
        saved['state']='draft_completed';atomic(receipt,saved)
        return {'listing_id':saved['listing_id'],'state':'draft','publication_performed':False}


def adopt_etsy_draft(engine, job_id, listing_id):
    """Reconcile an uncertain create by checking the supplied existing draft."""
    job=engine.job(job_id)
    if job['status'] not in ('approved','exported'):
        raise ValueError('Approve the exact package before reconciling its draft')
    if not configured()['etsy']:
        raise CapabilityError('Configure reviewed seller OAuth and shop identity')
    text=str(listing_id)
    if not text.isdecimal() or len(text)>24:
        raise ValueError('Supply an existing numeric Etsy listing ID')
    receipt=engine.root/'etsy_receipts'/job_id/'receipt.json'
    if not receipt.exists():raise ValueError('No uncertain creation receipt exists')
    shop=os.environ['PRODUCTION_ETSY_SHOP_ID']
    identity=fingerprint({'shop':shop,'revision':job['revision'],'artifacts':job['result']['manifest']['artifact_fingerprint']})
    with lock(receipt.with_suffix('.lock')):
        saved=json.loads(receipt.read_text())
        if saved.get('identity')!=identity or saved.get('state')!='create_unknown':
            raise ValueError('Only the matching uncertain create can be reconciled')
        headers={'Authorization':'Bearer '+os.environ['PRODUCTION_ETSY_ACCESS_TOKEN'],
                 'x-api-key':os.environ['ETSY_API_KEYSTRING']+':'+os.environ['ETSY_SHARED_SECRET']}
        with httpx.Client(headers=headers,timeout=30) as client:
            response=client.get('https://openapi.etsy.com/v3/application/listings/'+text);response.raise_for_status()
            listing=response.json()
        if str(listing.get('shop_id'))!=shop or listing.get('state')!='draft':
            raise ValueError('The supplied listing is not a draft in the configured shop')
        expected_type='physical' if is_physical(job['spec']) else 'download'
        if (listing.get('title')!=job['result']['listing']['title'] or listing.get('taxonomy_id')!=job['result']['listing']['taxonomy_id'] or listing.get('type')!=expected_type):
            raise ValueError('The supplied draft does not match the approved title, taxonomy and delivery')
        # This is adoption, not permission to publish or overwrite different files.
        saved.update(listing_id=int(text),state='uploading',reconciled_by_operator=True)
        atomic(receipt,saved)
    return {'listing_id':int(text),'state':'draft_adopted','publication_performed':False}


def adopt_printify_product(engine, job_id, product_id):
    job=engine.job(job_id); selection=job['spec']['provider']; text=str(product_id)
    if not is_physical(job['spec']) or not text.isalnum() or len(text)>64:
        raise ValueError('Supply a valid unpublished physical provider product ID')
    if not configured()['printify']:raise CapabilityError('Configure the reviewed Printify account')
    receipt=engine.root/'provider_receipts'/job_id/'printify.json'
    if not receipt.exists():raise ValueError('No uncertain provider receipt exists')
    with lock(receipt.parent/'printify.lock'):
        saved=json.loads(receipt.read_text())
        if saved.get('state')!='create_unknown' or not saved.get('upload_id'):
            raise ValueError('Only an uncertain provider creation can be reconciled')
        art=engine.file(job_id,'artwork.png')
        expected=fingerprint({'selection':selection,'art':hashlib.sha256(art.read_bytes()).hexdigest(),'shop':os.environ['PRINTIFY_SHOP_ID']})
        if saved.get('identity')!=expected:
            raise ValueError('Provider account, selection or artwork changed')
        with httpx.Client(headers={'Authorization':'Bearer '+os.environ['PRINTIFY_API_TOKEN']},timeout=30) as client:
            response=client.get('https://api.printify.com/v1/shops/'+os.environ['PRINTIFY_SHOP_ID']+'/products/'+text+'.json');response.raise_for_status()
            product=response.json()
        images=[image.get('id') for area in product.get('print_areas',[]) for placeholder in area.get('placeholders',[]) for image in placeholder.get('images',[])]
        if (product.get('title')!=job['spec']['name'] or product.get('blueprint_id')!=selection.get('blueprint_id') or
            product.get('print_provider_id')!=selection.get('print_provider_id') or saved['upload_id'] not in images or product.get('visible') is True):
            raise ValueError('The supplied product does not match the unpublished approved artwork/catalog')
        saved.update(product_id=text,state='created_unpublished',reconciled_by_operator=True);atomic(receipt,saved)
    return {'product_id':text,'state':'created_unpublished','publication_performed':False,'order_placed':False}
