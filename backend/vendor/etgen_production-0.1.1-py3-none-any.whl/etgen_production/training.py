"""Optional reviewed local LoRA experiments. No downloads or automatic promotion."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import uuid
from .providers import CapabilityError
from .artwork import atomic


def sha(path):
    digest=hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda:stream.read(1024*1024),b''):digest.update(block)
    return digest.hexdigest()


def start(engine,profile_name,approved):
    if approved is not True:raise ValueError('Explicitly approve this local training experiment')
    dataset=engine.training_dataset()
    if dataset['status']!='dataset_ready_for_review':raise CapabilityError('Training needs at least twenty reviewed, rights-approved source images')
    profiles=os.getenv('PRODUCTION_TRAINING_PROFILES');tool=os.getenv('PRODUCTION_AI_TOOLKIT_ROOT')
    if not profiles or not tool:raise CapabilityError('Install and benchmark a local trainer and reviewed experiment profile first')
    if not profile_name.replace('-','').replace('_','').isalnum():raise ValueError('Invalid training profile')
    profile=json.loads((Path(profiles)/(profile_name+'.json')).read_text())
    if profile.get('model_id')!='flux2-klein-4b' or profile.get('commercial_use_confirmed') is not True:
        raise CapabilityError('Only a reviewed commercially permitted local 4B model is enabled for this experiment adapter')
    gpu=shutil.which('nvidia-smi')
    if not gpu:raise CapabilityError('This trainer requires a benchmarked CUDA GPU; the current CPU/AMD host is not qualified')
    memory=subprocess.run([gpu,'--query-gpu=memory.total','--format=csv,noheader,nounits'],capture_output=True,text=True,timeout=10,check=True)
    if not any(int(value.strip())>=12288 for value in memory.stdout.splitlines()):raise CapabilityError('The reviewed training profile needs at least twelve GB GPU memory')
    runner=Path(tool).resolve()/'run.py';checkpoint=Path(profile['local_model']).resolve()
    if not runner.is_file() or not checkpoint.is_file() or sha(runner)!=profile.get('runner_sha256') or sha(checkpoint)!=profile.get('model_sha256'):
        raise ValueError('Trainer or local model fingerprint differs from the reviewed profile')
    run_id=uuid.uuid4().hex;folder=engine.root/'experiments'/run_id;folder.mkdir(parents=True)
    training=folder/'train';heldout=folder/'held-out';training.mkdir();heldout.mkdir()
    for example in dataset['examples']:
        source=engine.root/'assets'/(example['asset_id']+'.png')
        if not source.is_file():raise ValueError('Approved training source is missing')
        target=(heldout if example['split']=='held_out' else training)/source.name
        shutil.copyfile(source,target);target.with_suffix('.txt').write_text(example['caption'],encoding='utf-8')
    if len(list(training.glob('*.png')))<10 or len(list(heldout.glob('*.png')))<3:
        raise CapabilityError('The dataset needs ten training and three held-out examples; add approved data')
    # JSON is valid YAML; ai-toolkit accepts a reviewed local process configuration.
    config=profile['configuration'];process=config['config']['process'][0]
    process['model']['name_or_path']=str(checkpoint)
    process['datasets'][0]['folder_path']=str(training)
    process['training_folder']=str(folder/'outputs')
    config_file=folder/'experiment.json';atomic(config_file,config);atomic(folder/'dataset.json',dataset)
    environment={k:v for k,v in os.environ.items() if not k.startswith(('ETSY_','SUPABASE_','GOOGLE_','OPENAI_','ANTHROPIC_')) and k not in ('HF_TOKEN','HUGGING_FACE_HUB_TOKEN','PRODUCTION_ETSY_ACCESS_TOKEN')}
    environment['HF_HUB_OFFLINE']='1';environment['TRANSFORMERS_OFFLINE']='1'
    with (folder/'trainer.log').open('ab') as log:
        child=subprocess.Popen([sys.executable,str(runner),str(config_file)],cwd=runner.parent,env=environment,
                               stdout=log,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW if os.name=='nt' else 0)
    receipt={'run_id':run_id,'pid':child.pid,'profile':profile_name,'training_started':True,
             'model_promoted':False,'completion':'unverified_until_output_and_held_out_review','configuration_sha256':sha(config_file)}
    atomic(folder/'receipt.json',receipt);return receipt
