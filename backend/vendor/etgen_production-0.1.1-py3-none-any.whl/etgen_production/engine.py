"""Durable private jobs, immutable product revisions and explicit review boundaries."""
from contextlib import closing
from datetime import datetime, timezone
from pathlib import Path
import json
import os
import shutil
import sqlite3
import time
import uuid
import threading
from . import VERSION
from .models import ProductSpec, Review, fingerprint
from .render import render, manifest, inspect

REVIEW_CHECKS=('wording','usefulness','visual_quality','rights','files','mockups','facts')


class Engine:
    def __init__(self, root):
        self.root=Path(root).resolve()

    def connect(self):
        self.root.mkdir(parents=True,exist_ok=True)
        c=sqlite3.connect(self.root/'production.sqlite',timeout=15)
        c.row_factory=sqlite3.Row
        c.execute('PRAGMA journal_mode=WAL');c.execute('PRAGMA synchronous=FULL')
        c.executescript('''
          CREATE TABLE IF NOT EXISTS products(id TEXT PRIMARY KEY,name TEXT NOT NULL,created_at TEXT NOT NULL);
          CREATE TABLE IF NOT EXISTS specs(product_id TEXT NOT NULL,revision TEXT NOT NULL,payload TEXT NOT NULL,
              created_at TEXT NOT NULL,PRIMARY KEY(product_id,revision));
          CREATE TABLE IF NOT EXISTS jobs(id TEXT PRIMARY KEY,product_id TEXT NOT NULL,revision TEXT NOT NULL,
              status TEXT NOT NULL,owner TEXT,lease_until REAL,attempts INTEGER NOT NULL DEFAULT 0,
              next_attempt REAL NOT NULL DEFAULT 0,result TEXT,error TEXT,created_at TEXT NOT NULL,updated_at TEXT NOT NULL,
              UNIQUE(product_id,revision));
          CREATE TABLE IF NOT EXISTS events(id INTEGER PRIMARY KEY,job_id TEXT NOT NULL,action TEXT NOT NULL,
              payload TEXT NOT NULL,created_at TEXT NOT NULL);
          CREATE TABLE IF NOT EXISTS reviews(id TEXT PRIMARY KEY,job_id TEXT NOT NULL,payload TEXT NOT NULL,created_at TEXT NOT NULL);
          CREATE TABLE IF NOT EXISTS settings(name TEXT PRIMARY KEY,value TEXT NOT NULL);
          CREATE TABLE IF NOT EXISTS feedback(id TEXT PRIMARY KEY,product_id TEXT NOT NULL,payload TEXT NOT NULL,created_at TEXT NOT NULL);
          CREATE TABLE IF NOT EXISTS benchmarks(id TEXT PRIMARY KEY,payload TEXT NOT NULL,created_at TEXT NOT NULL);
          CREATE TABLE IF NOT EXISTS assets(id TEXT PRIMARY KEY,payload TEXT NOT NULL,created_at TEXT NOT NULL);
          CREATE TABLE IF NOT EXISTS profiles(id TEXT PRIMARY KEY,payload TEXT NOT NULL,enabled INTEGER NOT NULL,created_at TEXT NOT NULL);
          CREATE TABLE IF NOT EXISTS research_jobs(profile_id TEXT NOT NULL,demand_group TEXT NOT NULL,job_id TEXT NOT NULL,
              created_at TEXT NOT NULL,PRIMARY KEY(profile_id,demand_group));
        ''')
        return c

    @staticmethod
    def stamp(): return datetime.now(timezone.utc).isoformat()

    def event(self,c,job,action,value):
        c.execute('INSERT INTO events(job_id,action,payload,created_at) VALUES(?,?,?,?)',
                  (job,action,json.dumps(value,allow_nan=False),self.stamp()))

    def submit(self,data,product_id=None):
        spec=ProductSpec.model_validate(data).model_dump();revision=fingerprint(spec)
        now=self.stamp()
        with closing(self.connect()) as c,c:
            c.execute('BEGIN IMMEDIATE')
            if product_id and not c.execute('SELECT 1 FROM products WHERE id=?',(product_id,)).fetchone():
                raise ValueError('Product not found')
            # Stable actual-product identity; keywords are not duplicate-product IDs.
            product_id=product_id or 'product-'+fingerprint({'name':spec['name'].casefold(),'family':spec['family']})[:24]
            c.execute('INSERT OR IGNORE INTO products VALUES(?,?,?)',(product_id,spec['name'],now))
            c.execute('INSERT OR IGNORE INTO specs VALUES(?,?,?,?)',(product_id,revision,json.dumps(spec),now))
            old=c.execute('SELECT id FROM jobs WHERE product_id=? AND revision=?',(product_id,revision)).fetchone()
            if old: return self.job(old['id'],connection=c)
            job_id=uuid.uuid4().hex
            c.execute("UPDATE jobs SET status='superseded',owner=NULL,lease_until=NULL WHERE product_id=? AND revision<>? AND status NOT IN ('cancelled','rejected','superseded')",(product_id,revision))
            c.execute('INSERT INTO jobs(id,product_id,revision,status,created_at,updated_at) VALUES(?,?,?,?,?,?)',
                      (job_id,product_id,revision,'queued',now,now))
            self.event(c,job_id,'submitted',{'spec_fingerprint':revision})
            return self.job(job_id,connection=c)

    def job(self,job_id,connection=None):
        own=connection is None;c=connection or self.connect()
        try:
            row=c.execute('SELECT j.*,s.payload FROM jobs j JOIN specs s ON s.product_id=j.product_id AND s.revision=j.revision WHERE j.id=?',(job_id,)).fetchone()
            if not row: raise ValueError('Job not found')
            out=dict(row);out['spec']=json.loads(out.pop('payload'));out['result']=json.loads(out['result']) if out['result'] else None
            out['history']=[{**dict(r),'payload':json.loads(r['payload'])} for r in c.execute('SELECT action,payload,created_at FROM events WHERE job_id=? ORDER BY id',(job_id,))]
            out.pop('owner',None);out.pop('lease_until',None)
            return out
        finally:
            if own:c.close()

    def status(self):
        with closing(self.connect()) as c:
            ids=[r['id'] for r in c.execute('SELECT id FROM jobs ORDER BY created_at DESC LIMIT 100')]
            setting=c.execute("SELECT value FROM settings WHERE name='paused'").fetchone()
            return {'engine':VERSION,'paused':bool(setting and setting[0]=='1'),
                    'jobs':[self.job(i,connection=c) for i in ids], 'human_approval_required':True,
                    'profiles':[{'id':r['id'],'enabled':bool(r['enabled']),'spec':json.loads(r['payload'])['spec']} for r in c.execute('SELECT * FROM profiles ORDER BY created_at')],
                    'families':['planner','worksheet','wall_art','mug','apparel'], 'automatic_activation':False}

    def pause(self,paused):
        with closing(self.connect()) as c,c:
            c.execute("INSERT INTO settings VALUES('paused',?) ON CONFLICT(name) DO UPDATE SET value=excluded.value",('1' if paused else '0',))

    def action(self,job_id,action):
        with closing(self.connect()) as c,c:
            c.execute('BEGIN IMMEDIATE');row=c.execute('SELECT * FROM jobs WHERE id=?',(job_id,)).fetchone()
            if not row:raise ValueError('Job not found')
            if action=='retry' and row['status'] not in ('failed','needs_input','cancelled'):
                raise ValueError('Only failed, input-blocked or cancelled jobs can retry')
            if action=='cancel' and row['status'] not in ('queued','failed','needs_input'):
                raise ValueError('Wait for the current safe step before cancelling')
            if action not in ('retry','cancel'):raise ValueError('Unknown job action')
            c.execute('UPDATE jobs SET status=?,owner=NULL,lease_until=NULL,next_attempt=0,error=NULL,updated_at=? WHERE id=?',
                      ('queued' if action=='retry' else 'cancelled',self.stamp(),job_id))
            self.event(c,job_id,action,{})
        return self.job(job_id)

    def tick(self):
        owner=uuid.uuid4().hex;now=time.time()
        with closing(self.connect()) as c,c:
            c.execute('BEGIN IMMEDIATE')
            if c.execute("SELECT 1 FROM settings WHERE name='paused' AND value='1'").fetchone():return None
            # No overlapping expensive render, including another backend process.
            if c.execute("SELECT 1 FROM jobs WHERE status='running' AND lease_until>?",(now,)).fetchone():return None
            recovered=c.execute("SELECT id FROM jobs WHERE status='running' AND lease_until<=?",(now,)).fetchall()
            for r in recovered:self.event(c,r['id'],'recovered_expired_lease',{})
            c.execute("UPDATE jobs SET status='queued',owner=NULL,lease_until=NULL WHERE status='running' AND lease_until<=?",(now,))
            row=c.execute("SELECT * FROM jobs WHERE status='queued' AND next_attempt<=? ORDER BY created_at LIMIT 1",(now,)).fetchone()
            if not row:return None
            job_id=row['id']
            c.execute("UPDATE jobs SET status='running',owner=?,lease_until=?,attempts=attempts+1,updated_at=? WHERE id=?",(owner,now+120,self.stamp(),job_id))
            self.event(c,job_id,'render_started',{'attempt':row['attempts']+1})
        job=self.job(job_id);folder=self.root/'artifacts'/job_id
        stop_heartbeat=threading.Event()
        def heartbeat():
            while not stop_heartbeat.wait(10):
                with closing(self.connect()) as h,h:
                    h.execute('UPDATE jobs SET lease_until=? WHERE id=? AND owner=? AND status=\'running\'',(time.time()+120,job_id,owner))
        thread=threading.Thread(target=heartbeat,daemon=True);thread.start()
        retry_after=0
        try:
            if job['spec']['concept_method']=='local_model':
                from .providers import LocalModels
                with closing(self.connect()) as c:
                    notes=[str(json.loads(r['payload']).get('note',''))[:500] for r in c.execute('SELECT payload FROM feedback WHERE product_id=? ORDER BY created_at DESC LIMIT 8',(job['product_id'],))]
                concepts=LocalModels().concepts(job['spec'],feedback=notes)
                result={'concepts':concepts,'publication_performed':False}
                status='needs_concept_selection';error=None
                with closing(self.connect()) as c,c:
                    c.execute('UPDATE jobs SET status=?,result=?,owner=NULL,lease_until=NULL,updated_at=? WHERE id=? AND owner=?',
                        (status,json.dumps(result),self.stamp(),job_id,owner))
                    self.event(c,job_id,status,{})
                return self.job(job_id)
            artwork=None
            if job['spec']['artwork_id']:
                with closing(self.connect()) as c:
                    asset=c.execute('SELECT payload FROM assets WHERE id=?',(job['spec']['artwork_id'],)).fetchone()
                if not asset:raise ValueError('Approved source artwork not found')
                asset=json.loads(asset[0]);artwork=self.root/'assets'/asset['file']
                if not artwork.exists() or fingerprint(artwork.read_bytes().hex())!=asset['fingerprint']:
                    raise ValueError('Source artwork changed; restore it or create a revision')
            if job['spec']['artwork_method']=='comfy':
                from .artwork import generate
                artwork,_=generate(job['spec']['image_profile'],job['spec']['purpose'],self.root/'image_requests'/job_id)
            if (folder/'manifest.json').exists():
                package=json.loads((folder/'manifest.json').read_text());quality=inspect(folder,package,job['spec'])
                if package['spec_fingerprint']!=job['revision'] or quality['status']!='passed':
                    raise ValueError('Previously produced files changed; preserve and create a new revision')
            else:
                # Partial attempts are preserved, never used as finished output.
                attempt=self.root/'attempts'/job_id/uuid.uuid4().hex
                generated=render(job['spec'],attempt,artwork);package=manifest(attempt,generated,job['spec'])
                quality=inspect(attempt,package,job['spec'])
                (attempt/'manifest.json').write_text(json.dumps(package,indent=2))
                folder.parent.mkdir(parents=True,exist_ok=True)
                if folder.exists():raise ValueError('An unfinished artifact directory needs reconciliation')
                attempt.rename(folder)
            from .listing import build_listing
            result={'manifest':package,'quality':quality,'listing':build_listing(job['spec'],package),
                    'approval':None,'exported':False,'publication_performed':False}
            from .quality import perceptual_hash
            result['perceptual_hash']=perceptual_hash(folder/'preview.png')
            status='needs_review' if quality['status']=='passed' else 'failed'
            error=None
        except ValueError as e:
            status='needs_input';result=None;error=str(e)
            if type(e).__name__=='PendingArtwork':
                if 'still pending' in str(e):status='queued';retry_after=time.time()+60
                else:status='needs_reconciliation'
        except Exception as e:
            status='failed';result=None;error='Production failed: '+type(e).__name__
            import httpx
            if isinstance(e,httpx.HTTPError) and row['attempts']<2:
                status='queued';retry_after=time.time()+60*(2**row['attempts'])
        finally:
            stop_heartbeat.set();thread.join(timeout=2)
        with closing(self.connect()) as c,c:
            c.execute('BEGIN IMMEDIATE')
            changed=c.execute('UPDATE jobs SET status=?,result=?,error=?,owner=NULL,lease_until=NULL,next_attempt=?,updated_at=? WHERE id=? AND owner=?',
                (status,json.dumps(result) if result else None,error,retry_after,self.stamp(),job_id,owner)).rowcount
            if changed:self.event(c,job_id,status,{'error':error})
        return self.job(job_id)

    def import_asset(self,content,license_note):
        from PIL import Image
        from io import BytesIO
        if not isinstance(license_note,str) or len(license_note.strip())<10:raise ValueError('Record artwork ownership or license provenance')
        if len(content)>20_000_000:raise ValueError('Artwork exceeds twenty MB')
        with Image.open(BytesIO(content)) as im:
            if im.width*im.height>40_000_000:raise ValueError('Artwork exceeds local memory budget')
            im.verify()
        identity=fingerprint(content.hex());asset_id='asset-'+identity[:24]
        folder=self.root/'assets';folder.mkdir(parents=True,exist_ok=True);target=folder/(asset_id+'.png')
        if not target.exists():
            with Image.open(BytesIO(content)) as im:im.convert('RGBA').save(target)
        payload={'id':asset_id,'file':target.name,'fingerprint':fingerprint(target.read_bytes().hex()),
                 'license_note':license_note,'source_fingerprint':identity,'rights_certified':False}
        with closing(self.connect()) as c,c:
            c.execute('INSERT OR IGNORE INTO assets VALUES(?,?,?)',(asset_id,json.dumps(payload),self.stamp()))
        return payload

    def machine_review(self,job_id,vision=False):
        from .quality import assess
        job=self.job(job_id)
        path=self.file(job_id,'preview.png')
        result=assess(path,job['spec'],vision=vision)
        with closing(self.connect()) as c,c:self.event(c,job_id,'machine_assessment',result)
        return result

    def attach_mockups(self,job_id,names,provenance):
        job=self.job(job_id)
        if job['status']!='needs_review':raise ValueError('Mockup changes require a reviewable revision')
        result=job['result'];package=result['manifest'];folder=self.root/'artifacts'/job_id
        import hashlib
        old={v['name']:v for v in package['files']}
        for name in names:
            file=folder/name
            old[name]={'name':name,'bytes':file.stat().st_size,'sha256':hashlib.sha256(file.read_bytes()).hexdigest()}
        package['files']=sorted(old.values(),key=lambda v:v['name']);package['artifact_fingerprint']=fingerprint(package['files'])
        result['provider_mockups']=names;result['mockup_provenance']=provenance
        result['listing']['blockers']=[b for b in result['listing']['blockers'] if 'actual provider mockups' not in b]
        with closing(self.connect()) as c,c:
            c.execute('UPDATE jobs SET result=?,updated_at=? WHERE id=? AND status=\'needs_review\'',(json.dumps(result),self.stamp(),job_id))
            self.event(c,job_id,'provider_mockups_attached',{'files':names,'provenance':provenance})

    def duplicates(self,job_id):
        from .quality import distance
        job=self.job(job_id);value=(job['result'] or {}).get('perceptual_hash')
        if not value:return []
        with closing(self.connect()) as c:
            others=c.execute('SELECT id,result FROM jobs WHERE id<>? AND result IS NOT NULL',(job_id,)).fetchall()
            return [{'job_id':r['id'],'distance':distance(value,v)} for r in others
                    if (v:=json.loads(r['result']).get('perceptual_hash')) and distance(value,v)<=6]

    def review(self,job_id,data):
        review=Review.model_validate(data).model_dump();job=self.job(job_id)
        if job['status']!='needs_review' or not job['result']:raise ValueError('This job is not awaiting review')
        package=job['result']['manifest']
        if review['revision']!=job['revision'] or review['artifact_fingerprint']!=package['artifact_fingerprint']:
            raise ValueError('The reviewed revision or artifacts changed')
        quality=inspect(self.root/'artifacts'/job_id,package,job['spec'])
        if quality['status']!='passed':raise ValueError('Actual files failed verification; create a new revision')
        if review['decision']=='approve':
            if any(review['checks'].get(k) is not True for k in REVIEW_CHECKS):
                raise ValueError('Complete every actual-file, rights and product review')
            blockers=job['result']['listing']['blockers']
            if blockers:raise ValueError('Complete product facts before approval: '+'; '.join(blockers))
        result=job['result'];result['approval']=review
        with closing(self.connect()) as c,c:
            c.execute('BEGIN IMMEDIATE')
            changed=c.execute("UPDATE jobs SET status=?,result=?,updated_at=? WHERE id=? AND status='needs_review' AND revision=?",
                ('approved' if review['decision']=='approve' else 'rejected',json.dumps(result),self.stamp(),job_id,review['revision'])).rowcount
            if not changed:raise ValueError('Another operation changed this review')
            c.execute('INSERT INTO reviews VALUES(?,?,?,?)',(uuid.uuid4().hex,job_id,json.dumps(review),self.stamp()))
            self.event(c,job_id,review['decision'],review)
        return self.job(job_id)

    def file(self,job_id,name,*,customer=False):
        job=self.job(job_id)
        if not job['result']:raise ValueError('Files are not ready')
        package=job['result']['manifest']
        if name not in {r['name'] for r in package['files']}:raise ValueError('Unknown artifact')
        path=self.root/'artifacts'/job_id/name
        if not path.resolve().is_relative_to((self.root/'artifacts').resolve()):raise ValueError('Unsafe artifact path')
        if inspect(path.parent,package,job['spec'])['status']!='passed':raise ValueError('Artifact integrity failed')
        # Review download is explicitly labeled; distribution export requires approval.
        if customer and job['status'] not in ('approved','exported'):
            raise ValueError('Approve the exact package before distribution export')
        return path

    def export(self,job_id):
        from .marketplace import lock
        with lock(self.root/'locks'/(job_id+'.export.lock')):
            return self._export(job_id)

    def _export(self,job_id):
        job=self.job(job_id)
        if job['status'] not in ('approved','exported'):raise ValueError('Approve the exact package before export')
        folder=self.root/'exports'/job_id;folder.mkdir(parents=True,exist_ok=True)
        for record in job['result']['manifest']['files']:
            source=self.file(job_id,record['name'],customer=True);target=folder/source.name
            if target.exists():
                if fingerprint(target.read_bytes().hex())!=fingerprint(source.read_bytes().hex()):
                    raise ValueError('Existing export differs; preserve it and reconcile')
            else:shutil.copyfile(source,target)
        receipt={'job_id':job_id,'revision':job['revision'],'artifact_fingerprint':job['result']['manifest']['artifact_fingerprint'],
                 'approval':job['result']['approval'],'listing':job['result']['listing'],'publication_performed':False}
        target=folder/'receipt.json'
        if target.exists() and json.loads(target.read_text())!=receipt:raise ValueError('Export receipt changed; preserve and reconcile it')
        if not target.exists():
            from .artwork import atomic
            atomic(target,receipt)
        with closing(self.connect()) as c,c:
            c.execute("UPDATE jobs SET status='exported',updated_at=? WHERE id=? AND status IN ('approved','exported')",(self.stamp(),job_id))
            self.event(c,job_id,'exported',{'artifact_fingerprint':receipt['artifact_fingerprint']})
        return receipt

    def feedback(self,product_id,data):
        if not isinstance(data,dict) or not str(data.get('note','')).strip():raise ValueError('A feedback note is required')
        encoded=json.dumps(data,allow_nan=False)
        if len(encoded)>10000:raise ValueError('Feedback is too large')
        with closing(self.connect()) as c,c:
            if not c.execute('SELECT 1 FROM products WHERE id=?',(product_id,)).fetchone():raise ValueError('Product not found')
            c.execute('INSERT INTO feedback VALUES(?,?,?,?)',(uuid.uuid4().hex,product_id,encoded,self.stamp()))
        return {'saved':True,'sales_inferred':False}

    def save_profile(self,data):
        template=ProductSpec.model_validate(data['spec']).model_dump()
        if not isinstance(data.get('enabled'),bool) or data.get('facts_reviewed') is not True:
            raise ValueError('A production recipe requires explicit fact review and enabled/disabled selection')
        if template['concept_method']!='local_model':
            raise ValueError('Automatic research recipes generate distinct concepts for human selection')
        profile_id=fingerprint({'name':template['name'],'family':template['family']})[:24]
        payload={'spec':template,'facts_reviewed':True}
        with closing(self.connect()) as c,c:
            c.execute('INSERT INTO profiles VALUES(?,?,?,?) ON CONFLICT(id) DO UPDATE SET payload=excluded.payload,enabled=excluded.enabled',
                      (profile_id,json.dumps(payload),int(data['enabled']),self.stamp()))
        return {'id':profile_id,'enabled':data['enabled'],'human_concept_selection_required':True}

    def enqueue_research(self,candidates):
        # Operator-reviewed recipes alone can start production from qualified research.
        with closing(self.connect()) as c:
            profiles=[dict(r) for r in c.execute('SELECT * FROM profiles WHERE enabled=1')]
            today=datetime.now(timezone.utc).date().isoformat()
            count=c.execute('SELECT COUNT(*) FROM research_jobs WHERE created_at>=?',(today,)).fetchone()[0]
        created=[]
        for profile in profiles:
            template=json.loads(profile['payload'])['spec']
            for evidence in candidates:
                group=evidence['demand_group']
                with closing(self.connect()) as c:
                    exists=c.execute('SELECT * FROM research_jobs WHERE profile_id=? AND demand_group=?',(profile['id'],group)).fetchone()
                if exists and (exists['job_id']!='pending' or (datetime.now(timezone.utc)-datetime.fromisoformat(exists['created_at'])).total_seconds()<60):continue
                keyword=evidence['keyword']
                import re
                formats={'planner':r'\b(planner|organizer)\b','worksheet':r'\b(worksheet|worksheets|sheet|sheets)\b',
                         'wall_art':r'\b(poster|print|prints|wall art)\b','mug':r'\b(mug|mugs|cup|cups)\b',
                         'apparel':r'\b(shirt|shirts|tee|tees|apparel|hoodie)\b'}
                if not re.search(formats[template['family']],keyword,re.I):continue
                # No source/type match is invented; the recipe must match this format.
                from .providers import related
                match=related(template,[{'family':template['family'],'keyword':keyword,'purpose':''}])
                if not match['matches'] or match['matches'][0]['similarity']<.25:continue
                spec={**template,'keyword':keyword,'name':(keyword+' '+template['family'].replace('_',' '))[:120],
                      'research':evidence,'supporting_keywords':evidence.get('supporting_keywords',[])}
                with closing(self.connect()) as c,c:
                    c.execute('BEGIN IMMEDIATE')
                    current=c.execute('SELECT * FROM research_jobs WHERE profile_id=? AND demand_group=?',(profile['id'],group)).fetchone()
                    if current:
                        if current['job_id']!='pending' or (datetime.now(timezone.utc)-datetime.fromisoformat(current['created_at'])).total_seconds()<60:continue
                        c.execute('UPDATE research_jobs SET created_at=? WHERE profile_id=? AND demand_group=?',(self.stamp(),profile['id'],group))
                    else:
                        if c.execute('SELECT COUNT(*) FROM research_jobs WHERE created_at>=?',(today,)).fetchone()[0]>=10:return created
                        c.execute('INSERT INTO research_jobs VALUES(?,?,?,?)',(profile['id'],group,'pending',self.stamp()))
                job=self.submit(spec)
                with closing(self.connect()) as c,c:
                    c.execute('UPDATE research_jobs SET job_id=? WHERE profile_id=? AND demand_group=?',(job['id'],profile['id'],group))
                created.append(job);count+=1
        return created

    def enable_profile(self,profile_id,enabled):
        if not isinstance(enabled,bool):raise ValueError('Choose an explicit enabled state')
        with closing(self.connect()) as c,c:
            if not c.execute('UPDATE profiles SET enabled=? WHERE id=?',(int(enabled),profile_id)).rowcount:raise ValueError('Recipe not found')
        return {'id':profile_id,'enabled':enabled}

    def training_dataset(self):
        # Fine-tuning is gated on actual reviewed source images, never fabricated data.
        with closing(self.connect()) as c:
            rows=c.execute("SELECT * FROM jobs WHERE status IN ('approved','exported')").fetchall()
            assets={r['id']:json.loads(r['payload']) for r in c.execute('SELECT * FROM assets')}
        examples=[]
        for row in rows:
            job=self.job(row['id']);asset=assets.get(job['spec']['artwork_id'])
            if asset and job['result']['approval']['checks'].get('rights'):
                examples.append({'asset_id':asset['id'],'source_fingerprint':asset['source_fingerprint'],
                                 'license_note':asset['license_note'],'caption':job['spec']['purpose'],
                                 'split':'held_out' if int(asset['source_fingerprint'][:2],16)%5==0 else 'train'})
        examples=list({e['asset_id']:e for e in examples}.values())
        return {'status':'dataset_ready_for_review' if len(examples)>=20 else 'needs_twenty_approved_source_images',
                'examples':examples,'training_started':False,'model_promoted':False}

    def benchmark(self,data):
        required=('candidate','baseline','fixture_ids','human_note','metrics')
        if not isinstance(data,dict) or any(not data.get(k) for k in required):raise ValueError('A comparison needs candidate, baseline, held-out fixtures, metrics and human review')
        encoded=json.dumps(data,allow_nan=False)
        if len(encoded)>20000:raise ValueError('Benchmark record is too large')
        with closing(self.connect()) as c,c:c.execute('INSERT INTO benchmarks VALUES(?,?,?)',(uuid.uuid4().hex,encoded,self.stamp()))
        return {'saved':True,'automatically_promoted':False}
