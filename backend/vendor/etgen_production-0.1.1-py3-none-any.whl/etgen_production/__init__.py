"""Namespaced production engine shared by EtGen clients. No import-time writes."""
VERSION = 'etgen-production-v1'
