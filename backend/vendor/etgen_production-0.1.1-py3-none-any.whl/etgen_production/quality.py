"""Machine assessments retain uncertainty; hard file checks and review are separate."""
import base64
import json
import shutil
import subprocess
from PIL import Image
from .providers import LocalModels, CapabilityError, ocr_binary


def assess(path,spec,*,vision=False):
    result={'ocr':{'status':'unavailable'},'vision':{'status':'not_requested'},'automatically_approved':False}
    executable=ocr_binary()
    if executable:
        process=subprocess.run([executable,str(path),'stdout','--psm','11'],capture_output=True,text=True,timeout=30)
        text=process.stdout.strip() if process.returncode==0 else ''
        expected=spec['content'][:1] if spec['family'] in ('planner','worksheet') else spec['content']
        result['ocr']={'status':'completed' if process.returncode==0 else 'failed','recognized_text':text[:5000],
                       'scope':'preview_only; complete PDF wording is checked separately',
                       'expected_words':expected,'human_reconciliation_required':True}
    if vision:
        try:
            with Image.open(path) as image:
                from io import BytesIO
                image.thumbnail((1200,1200));buffer=BytesIO();image.convert('RGB').save(buffer,format='JPEG')
            output,provenance=LocalModels().critique(spec,image=base64.b64encode(buffer.getvalue()).decode())
            result['vision']={'status':'completed','assessment':output,'provenance':provenance}
        except Exception as exc:
            result['vision']={'status':'unavailable_or_failed','error_type':type(exc).__name__}
    return result


def perceptual_hash(path):
    with Image.open(path) as image:
        image=image.convert('L').resize((9,8))
        pixels=list(image.get_flattened_data());bits=[pixels[y*9+x]>pixels[y*9+x+1] for y in range(8) for x in range(8)]
    return hex(sum(int(bit)<<i for i,bit in enumerate(bits)))


def distance(a,b): return (int(a,16)^int(b,16)).bit_count()
