"""Controlled local image workflows; only reviewed local node graphs execute."""
from pathlib import Path
import hashlib
import json
import os
import time
import httpx
from .models import fingerprint
from .providers import CapabilityError,local_url

# Network/paid/custom execution nodes are deliberately absent.
NODES={'CheckpointLoaderSimple','UNETLoader','CLIPLoader','DualCLIPLoader','VAELoader',
       'CLIPTextEncode','EmptyLatentImage','EmptySD3LatentImage','KSampler','KSamplerAdvanced',
       'VAEDecode','VAEEncode','VAEEncodeForInpaint','SaveImage','LoadImage','ImageScale',
       'ImageCompositeMasked','ControlNetLoader','ControlNetApplyAdvanced','LoraLoader',
       'ModelSamplingFlux','FluxGuidance','ConditioningZeroOut','BasicScheduler','KSamplerSelect',
       'RandomNoise','BasicGuider','SamplerCustomAdvanced'}


class PendingArtwork(CapabilityError):pass


def atomic(path,data):
    temporary=path.with_suffix('.tmp')
    temporary.write_text(json.dumps(data,indent=2));temporary.replace(path)


def generate(profile_name,prompt,receipt_folder):
    # Profiles are installed by an operator; the browser cannot supply arbitrary graphs.
    profile_root=os.getenv('PRODUCTION_COMFY_PROFILES')
    if not profile_root:raise CapabilityError('Install and review a local image workflow profile first')
    if not profile_name.replace('-','').replace('_','').isalnum():raise ValueError('Invalid image profile')
    root=Path(profile_root).resolve();file=root/(profile_name+'.json')
    if not file.resolve().is_relative_to(root):raise ValueError('Unsafe profile')
    data=json.loads(file.read_text())
    if data.get('commercial_use_confirmed') is not True or not data.get('license_note') or not data.get('model_sha256'):
        raise CapabilityError('Image profile needs reviewed model license and model fingerprint')
    graph=data['workflow']
    if any(node.get('class_type') not in NODES for node in graph.values()):
        raise CapabilityError('Only reviewed local generation, reference, mask and layout nodes are allowed')
    slot=str(data['prompt_node'])
    if graph.get(slot,{}).get('class_type')!='CLIPTextEncode':raise ValueError('Profile prompt node must encode text')
    graph[slot]['inputs']['text']=prompt
    url=local_url('PRODUCTION_COMFY_URL','http://127.0.0.1:8188')
    folder=Path(receipt_folder);folder.mkdir(parents=True,exist_ok=True);receipt=folder/'comfy-receipt.json'
    identity=fingerprint({'profile':data,'prompt':prompt})
    saved=json.loads(receipt.read_text()) if receipt.exists() else {}
    if saved and saved['identity']!=identity:raise ValueError('Image inputs changed; create a new image request')
    if saved.get('state')=='create_unknown':raise PendingArtwork('Reconcile the local image request before retrying')
    if not saved.get('prompt_id'):
        atomic(receipt,{'identity':identity,'state':'create_unknown'})
        r=httpx.post(url+'/prompt',json={'prompt':graph},timeout=20)
        if 400<=r.status_code<500:
            atomic(receipt,{'identity':identity,'state':'rejected'});r.raise_for_status()
        r.raise_for_status();prompt_id=r.json().get('prompt_id')
        if not prompt_id:raise PendingArtwork('Local image server returned no receipt; reconcile before retrying')
        saved={'identity':identity,'prompt_id':prompt_id,'state':'running'};atomic(receipt,saved)
    deadline=time.monotonic()+75
    while time.monotonic()<deadline:
        r=httpx.get(url+'/history/'+saved['prompt_id'],timeout=10);r.raise_for_status()
        history=r.json().get(saved['prompt_id'],{})
        if history.get('status',{}).get('status_str')=='error':raise CapabilityError('Local image workflow failed; inspect its saved receipt')
        outputs=[i for node in history.get('outputs',{}).values() for i in node.get('images',[])]
        if outputs:
            image=outputs[0];response=httpx.get(url+'/view',params=image,timeout=30);response.raise_for_status()
            if len(response.content)>20_000_000:raise ValueError('Artwork exceeds the local input bound')
            target=folder/'generated.png'
            if not target.exists():target.write_bytes(response.content)
            saved.update(state='completed',sha256=hashlib.sha256(target.read_bytes()).hexdigest(),
                         profile=profile_name,license_note=data['license_note'],model_sha256=data['model_sha256'])
            atomic(receipt,saved);return target,saved
        time.sleep(2)
    raise PendingArtwork('Local generation is still pending; retry will reuse its prompt receipt')
