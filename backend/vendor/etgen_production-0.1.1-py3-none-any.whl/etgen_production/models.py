"""Product facts are supplied or catalog verified; generated suggestions are separate."""
from typing import Literal
import hashlib
import json
import re
from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator


def fingerprint(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()).hexdigest()


class ProductSpec(BaseModel):
    model_config = ConfigDict(extra='forbid', str_strip_whitespace=True)
    schema_version: Literal[1] = 1
    name: str = Field(min_length=3, max_length=120)
    keyword: str = Field(min_length=3, max_length=160)
    buyer: str = Field(min_length=3, max_length=300)
    purpose: str = Field(min_length=10, max_length=2000)
    family: Literal['planner', 'worksheet', 'wall_art', 'mug', 'apparel']
    content: list[str] = Field(min_length=1, max_length=60)
    personalization: str = Field(default='', max_length=80)
    size: Literal['letter', 'a4', '8x10', '12x16', 'provider'] = 'letter'
    palette: Literal['ink', 'sage', 'clay'] = 'ink'
    layout: Literal['classic', 'editorial', 'minimal'] = 'classic'
    price: float | None = Field(default=None, gt=0, le=100000, allow_inf_nan=False)
    unit_cost: float | None = Field(default=None, ge=0, le=100000, allow_inf_nan=False)
    delivery: str = Field(default='', max_length=1000)
    materials: str = Field(default='', max_length=500)
    category_id: int | None = Field(default=None, gt=0)
    rights_note: str = Field(default='', max_length=1000)
    supporting_keywords: list[str] = Field(default_factory=list, max_length=14)
    tags: list[str] = Field(default_factory=list, max_length=13)
    # Facts required for physical products come from a reviewed provider selection.
    provider: dict = Field(default_factory=dict)
    research: dict = Field(default_factory=dict)
    artwork_id: str | None = None
    concept_method: Literal['authored', 'local_model'] = 'authored'
    artwork_method: Literal['template', 'comfy'] = 'template'
    image_profile: str = Field(default='', max_length=80)

    @field_validator('tags')
    @classmethod
    def unique_tags(cls, values):
        if any(not 2 <= len(v) <= 20 for v in values) or len({v.casefold() for v in values}) != len(values):
            raise ValueError('Tags must be unique and contain 2–20 characters')
        return values

    @field_validator('name', 'keyword', 'buyer', 'purpose', 'personalization', 'content')
    @classmethod
    def printable(cls, value):
        items = value if isinstance(value, list) else [value]
        for item in items:
            if not isinstance(item, str) or not item.strip() or len(item) > 2000:
                if item == '' and not isinstance(value, list):
                    continue
                raise ValueError('Content must contain nonempty text')
            if any(ord(c) < 32 and c not in '\n\t' for c in item):
                raise ValueError('Control characters are not printable')
        return [item.strip() for item in value] if isinstance(value, list) else value

    @model_validator(mode='after')
    def product_dimensions(self):
        if self.family in ('planner','worksheet') and re.search(r'\b(editable|fillable|interactive|automatic calculations)\b',self.purpose,re.I):
            raise ValueError('This PDF template does not provide editable fields or interactive functions')
        if self.family in ('mug', 'apparel') and self.size != 'provider':
            raise ValueError('Physical artwork requires an exact provider print area')
        if self.family in ('planner', 'worksheet') and self.size not in ('a4', 'letter'):
            raise ValueError('Document products require Letter or A4')
        if self.family == 'wall_art' and self.size not in ('8x10', '12x16'):
            raise ValueError('Wall art requires an explicit print size')
        return self


class Concept(BaseModel):
    model_config = ConfigDict(extra='forbid')
    name: str = Field(min_length=3, max_length=120)
    buyer_task: str = Field(min_length=10, max_length=500)
    purpose: str = Field(min_length=10, max_length=1200)
    composition: str = Field(min_length=10, max_length=1000)
    content: list[str] = Field(min_length=1, max_length=60)
    differentiation: str = Field(min_length=10, max_length=500)


class ConceptBatch(BaseModel):
    concepts: list[Concept] = Field(min_length=3, max_length=8)


class Review(BaseModel):
    model_config = ConfigDict(extra='forbid', str_strip_whitespace=True)
    revision: str
    artifact_fingerprint: str
    decision: Literal['approve', 'reject']
    note: str = Field(min_length=10, max_length=2000)
    checks: dict[str, bool]


def normalized(text):
    return ' '.join(re.findall(r'[a-z0-9]+', str(text).casefold()))
