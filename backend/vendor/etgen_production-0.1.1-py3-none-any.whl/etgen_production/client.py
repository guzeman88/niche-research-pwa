"""Desktop compatibility client; private engine is owned by the app backend."""
import httpx
from urllib.parse import urlparse


class ProductionClient:
    def __init__(self,url='http://127.0.0.1:18020',token=None):
        if urlparse(url).hostname not in ('localhost','127.0.0.1','::1') and not url.startswith('https://'):
            raise ValueError('Remote production requires HTTPS and authenticated operator access')
        self.url=url.rstrip('/')+'/api/production'
        self.headers={'Authorization':'Bearer '+token} if token else {}

    def request(self,path='',data=None):
        r=httpx.request('GET' if data is None else 'POST',self.url+path,headers=self.headers,json=data,timeout=30)
        r.raise_for_status();return r.json()

    def status(self):return self.request()
    def submit(self,spec,product_id=None):return self.request('/jobs',{'spec':spec,'product_id':product_id})
    def review(self,job_id,review):return self.request('/jobs/'+job_id+'/review',review)
    def export(self,job_id):return self.request('/jobs/'+job_id+'/export',{})
