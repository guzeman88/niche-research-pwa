"""Reviewed layout masters: exact text, embedded licensed font, real deliverables."""
from pathlib import Path
from io import BytesIO
import hashlib
import json
import zipfile
from xml.sax.saxutils import escape
from PIL import Image, ImageDraw, ImageFont
from reportlab.pdfgen.canvas import Canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from pypdf import PdfReader
from .models import fingerprint

FONT = Path(__file__).parent / 'fonts/NotoSans-Regular.ttf'
PALETTES = {'ink': ('#213547','#64748b','#edf1f4'), 'sage': ('#24463b','#547363','#eaf1ec'),
            'clay': ('#603f35','#906b5e','#f5ede8')}
TEMPLATE_VERSION = 'etgen-masters-1'


def font_register():
    if 'EtGenNoto' not in pdfmetrics.getRegisteredFontNames():
        pdfmetrics.registerFont(TTFont('EtGenNoto', str(FONT)))


def wrap(text, width, size):
    font_register()
    mapping=pdfmetrics.getFont('EtGenNoto').face.charToGlyph
    if any(ord(c) not in mapping for c in text if not c.isspace()):
        raise ValueError('The production font does not support a character in this wording')
    lines=[]; current=''
    for paragraph in text.split('\n'):
        for word in paragraph.split():
            if pdfmetrics.stringWidth(word,'EtGenNoto',size) > width:
                raise ValueError('A word exceeds the printable area; shorten it before rendering')
            candidate=(current+' '+word).strip()
            if pdfmetrics.stringWidth(candidate,'EtGenNoto',size)>width:
                lines.append(current);current=word
            else: current=candidate
        if current: lines.append(current)
        current=''
    return lines or ['']


class Page:
    def __init__(self,width,height):
        self.width,self.height=width,height;self.ops=[]

    def text(self,x,y,text,size=12,color='#213547',width=None,max_lines=12):
        lines=wrap(text,width or self.width-x-48,size)
        if len(lines)>max_lines or y+len(lines)*size*1.5>self.height-36:
            raise ValueError('Text exceeds the reviewed template layout')
        for n,line in enumerate(lines):
            self.ops.append(('text',x,y+n*size*1.5,line,size,color))
        return y+len(lines)*size*1.5

    def line(self,x,y,x2,y2,color='#d4dde2'):
        self.ops.append(('line',x,y,x2,y2,color))

    def rect(self,x,y,w,h,color):
        if x<0 or y<0 or x+w>self.width or y+h>self.height:
            raise ValueError('Template exceeds page bounds')
        self.ops.append(('rect',x,y,w,h,color))

    def image(self,path,x,y,w,h):
        self.ops.append(('image',str(path),x,y,w,h))

    def pdf(self,canvas):
        for op in self.ops:
            if op[0]=='text':
                _,x,y,text,size,color=op;canvas.setFillColor(color);canvas.setFont('EtGenNoto',size)
                canvas.drawString(x,self.height-y-size,text)
            elif op[0]=='line':
                _,x,y,x2,y2,color=op;canvas.setStrokeColor(color);canvas.setLineWidth(.6)
                canvas.line(x,self.height-y,x2,self.height-y2)
            elif op[0]=='image':
                _,path,x,y,w,h=op;canvas.drawImage(path,x,self.height-y-h,w,h,mask='auto',preserveAspectRatio=True,anchor='c')
            else:
                _,x,y,w,h,color=op;canvas.setFillColor(color)
                canvas.rect(x,self.height-y-h,w,h,fill=1,stroke=0)

    def png(self,target,scale=2):
        img=Image.new('RGB',(round(self.width*scale),round(self.height*scale)),'white');draw=ImageDraw.Draw(img)
        for op in self.ops:
            if op[0]=='text':
                _,x,y,text,size,color=op
                draw.text((round(x*scale),round(y*scale)),text,fill=color,font=ImageFont.truetype(str(FONT),round(size*scale)),anchor='lt')
            elif op[0]=='line':
                _,x,y,x2,y2,color=op;draw.line((x*scale,y*scale,x2*scale,y2*scale),fill=color,width=max(1,round(scale)))
            elif op[0]=='image':
                _,path,x,y,w,h=op
                with Image.open(path) as art:
                    art=art.convert('RGBA');art.thumbnail((round(w*scale),round(h*scale)))
                    img.paste(art,(round(x*scale+(w*scale-art.width)/2),round(y*scale+(h*scale-art.height)/2)),art)
            else:
                _,x,y,w,h,color=op;draw.rectangle((x*scale,y*scale,(x+w)*scale,(y+h)*scale),fill=color)
        img.save(target)


def render(spec, folder, artwork=None):
    folder=Path(folder);folder.mkdir(parents=True,exist_ok=True);font_register()
    family=spec['family'];ink,accent,tint=PALETTES[spec['palette']]
    if family in ('mug','apparel'):
        selection=spec['provider'];width=selection.get('width_px');height=selection.get('height_px')
        if not isinstance(width,int) or not isinstance(height,int) or not 300<=width<=12000 or not 300<=height<=12000:
            raise ValueError('Choose verified provider print-area dimensions before physical rendering')
        if width*height>40_000_000:raise ValueError('The print area exceeds the local render memory budget')
        page=Page(width,height)
        text='\n'.join(spec['content']+([spec['personalization']] if spec['personalization'] else []))
        size=max(24,min(width/18,height/8)); lines=wrap(text,width*.8,size)
        if len(lines)*size*1.5>height*.7: raise ValueError('Wording is too long for the print area')
        page.text(width*.1,height*.15,text,size,ink,width*.8)
        # Production PNG contains only approved wording, transparent background.
        image=Image.new('RGBA',(width,height),(0,0,0,0));d=ImageDraw.Draw(image)
        font=ImageFont.truetype(str(FONT),round(size))
        if artwork:
            with Image.open(artwork) as art:
                art=art.convert('RGBA');art.thumbnail((round(width*.8),round(height*.45)))
                image.alpha_composite(art,(round((width-art.width)/2),round(height*.5)))
        for i,line in enumerate(lines):
            d.text((width/2,height*.15+i*size*1.5),line,font=font,fill=ink,anchor='mt')
        image.save(folder/'artwork.png')
        svg='<svg xmlns="http://www.w3.org/2000/svg" width="%s" height="%s" viewBox="0 0 %s %s">'%(width,height,width,height)
        for i,line in enumerate(lines):
            svg+='<text x="%s" y="%s" text-anchor="middle" font-family="Noto Sans" font-size="%s" fill="%s">%s</text>'%(width/2,height*.15+(i+1)*size*1.5,size,ink,escape(line))
        (folder/'editable-master.svg').write_text(svg+'</svg>',encoding='utf-8')
        with Image.open(folder/'artwork.png') as im:
            # Flat source proof, never claimed to be a manufactured product mockup.
            bg=Image.new('RGBA',im.size,'white');bg.alpha_composite(im)
            bg.thumbnail((1000,1000));bg.convert('RGB').save(folder/'preview.png')
        return {'customer_files':['artwork.png'], 'masters':['editable-master.svg'],
                'preview':'preview.png','preview_kind':'flat_artwork_proof_not_product_mockup',
                'template':TEMPLATE_VERSION,'font_sha256':hashlib.sha256(FONT.read_bytes()).hexdigest()}
    dimensions={'letter':(612,792),'a4':(595.28,841.89),'8x10':(576,720),'12x16':(864,1152)}
    width,height=dimensions[spec['size']]; pages=[]
    if family=='wall_art':
        p=Page(width,height)
        p.rect(0,0,width,height,'#ffffff')
        if artwork:p.image(artwork,width*.13,height*.15,width*.74,height*.5)
        size=min(36,width/16)
        text='\n'.join(spec['content']+([spec['personalization']] if spec['personalization'] else []))
        p.text(width*.13,height*.72 if artwork else height*.26,text,size,ink,width*.74,max_lines=4 if artwork else 10)
        if spec['layout']!='minimal': p.line(width*.13,height*.18,width*.35,height*.18,accent)
        pages=[p]
    else:
        for index,content in enumerate(spec['content']):
            p=Page(width,height);p.rect(0,0,width,10,accent)
            p.text(48,30,spec['name'],11,accent,max_lines=2)
            y=p.text(48,75,content,26,ink,width-96,max_lines=4)+28
            if spec['personalization']: y=p.text(48,y,spec['personalization'],12,accent)+16
            if family=='planner':
                for label in ('Priorities','Schedule','Notes'):
                    if spec['layout']=='minimal':
                        p.text(48,y+4,label,12,accent)
                    elif spec['layout']=='editorial':
                        p.rect(48,y,4,26,accent);p.text(62,y+4,label,12,ink);p.line(160,y+18,width-48,y+18)
                    else:p.rect(48,y,width-96,26,tint);p.text(58,y+4,label,12,ink)
                    y+=40
                    for _ in range(4): p.line(48,y,width-48,y);y+=23
                    y+=15
            else:
                p.text(48,y,'Response',12,accent);y+=34
                while y<height-92: p.line(48,y,width-48,y);y+=28
            p.text(48,height-58,f'{index+1} / {len(spec["content"])}',9,accent)
            if y>height-60: raise ValueError('Writing areas exceed the page; shorten the heading')
            pages.append(p)
    pdf=Canvas(str(folder/'customer.pdf'),pagesize=(width,height),invariant=1)
    pdf.setTitle(spec['name']);pdf.setAuthor('EtGen')
    for i,page in enumerate(pages):
        pdf.bookmarkPage(f'page-{i+1}');pdf.addOutlineEntry(spec['content'][i][:80],f'page-{i+1}',0)
        page.pdf(pdf);pdf.showPage()
    pdf.save();pages[0].png(folder/'preview.png')
    (folder/'instructions.txt').write_text(spec['name']+'\n'+spec['purpose']+'\n\n'
        +'Included: customer.pdf ('+str(len(pages))+' pages). Print size: '+spec['size']+'.\n'
        +'Use actual size when printing. No physical item is included.\n'+spec['delivery'],encoding='utf-8')
    with zipfile.ZipFile(folder/'customer.zip','w',zipfile.ZIP_DEFLATED) as bundle:
        for name in ('customer.pdf','instructions.txt'):
            info=zipfile.ZipInfo(name,date_time=(2026,1,1,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED
            bundle.writestr(info,(folder/name).read_bytes())
    return {'customer_files':['customer.pdf','instructions.txt','customer.zip'], 'masters':[],
            'preview':'preview.png','preview_kind':'same_layout_commands_as_customer_pdf',
            'pages':len(pages),'template':TEMPLATE_VERSION,
            'font_sha256':hashlib.sha256(FONT.read_bytes()).hexdigest()}


def manifest(folder, result, spec):
    folder=Path(folder)
    files=[{'name':p.name,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
           for p in sorted(folder.iterdir()) if p.is_file() and p.name!='manifest.json']
    return {'schema_version':1,'spec_fingerprint':fingerprint(spec),'render':result,'files':files,
            'artifact_fingerprint':fingerprint(files),'license':'Noto Sans SIL Open Font License; see engine fonts/LICENSE.txt'}


def inspect(folder, package, spec):
    checks=[];folder=Path(folder)
    for record in package['files']:
        p=folder/record['name']
        checks.append({'check':'integrity:'+record['name'],'passed':p.exists() and hashlib.sha256(p.read_bytes()).hexdigest()==record['sha256']})
    if (folder/'customer.pdf').exists():
        pdf=PdfReader(folder/'customer.pdf')
        text=' '.join(p.extract_text() or '' for p in pdf.pages)
        checks.append({'check':'customer_page_count','passed':len(pdf.pages)==package['render']['pages']})
        checks.append({'check':'exact_customer_wording','passed':all(' '.join(t.split()) in ' '.join(text.split()) for t in spec['content'])})
    if (folder/'artwork.png').exists():
        with Image.open(folder/'artwork.png') as image:
            checks.append({'check':'provider_dimensions','passed':image.size==(spec['provider']['width_px'],spec['provider']['height_px'])})
            checks.append({'check':'transparent_print_file','passed':image.mode=='RGBA'})
    with Image.open(folder/'preview.png') as image:
        image.verify();checks.append({'check':'preview_opens','passed':True})
    return {'status':'passed' if all(c['passed'] for c in checks) else 'failed','checks':checks,
            'visual_review':'required','rights_review':'required','ocr':'not_run',
            'manufacturing':'not_verified' if spec['family'] in ('mug','apparel') else 'not_applicable'}
