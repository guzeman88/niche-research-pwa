"""Factual copy from exact product specs; formatting is not an SEO prediction."""
from .models import normalized
from .capabilities import is_physical, delivery_kind


def build_listing(spec,package):
    phrases=[spec['keyword'],*spec['supporting_keywords'],spec['name'],spec['family'].replace('_',' ')]
    tags=[]
    for phrase in phrases:
        words=normalized(phrase).split()
        candidates=[normalized(phrase)]+[' '.join(words[i:i+n]) for n in (3,2) for i in range(max(0,len(words)-n+1))]
        for tag in candidates:
            if 2<=len(tag)<=20 and tag not in tags:tags.append(tag)
    tags=spec.get('tags') or tags[:13];digital=not is_physical(spec)
    description=spec['name']+'\n\n'+spec['purpose']+'\n\nFor: '+spec['buyer']
    description+='\n\nIncluded content:\n'+'\n'.join('- '+s for s in spec['content'])
    if digital:
        description+='\n\n'+('Made-to-order digital file.' if delivery_kind(spec)=='made_to_order_digital' else 'Digital download.')+' No physical item. Size: '+spec['size']+'.'
        description+='\nFiles: '+', '.join(package['render']['customer_files'])
    else:description+='\n\nMaterials: '+spec['materials']
    if spec['personalization']:description+='\nPersonalization: '+spec['personalization']
    if spec['delivery']:description+='\nDelivery and terms: '+spec['delivery']
    blockers=[]
    for key,label in [('price','selling price'),('unit_cost','actual total variable cost'),('delivery','delivery and return terms'),
                      ('rights_note','rights provenance'),('category_id','verified Etsy taxonomy category')]:
        if spec.get(key) is None or spec.get(key)=='':blockers.append('Supply '+label)
    if spec['price'] is not None and spec['unit_cost'] is not None and spec['price']<=spec['unit_cost']:
        blockers.append('Actual contribution must be positive')
    if not digital:
        if not spec['materials']:blockers.append('Confirm catalog materials')
        if not spec['provider'].get('mockups_reviewed'):blockers.append('Attach and review actual provider mockups')
        if not spec['provider'].get('shipping_profile_id') or not spec['provider'].get('readiness_state_id'):
            blockers.append('Verify shipping profile and readiness state')
    if len(tags)!=13:blockers.append('Supply thirteen relevant unique tags; the generator does not add filler')
    if spec.get('schema_version',1)==2:
        blockers.extend(package['render'].get('blockers',[]))
        verified=package['render'].get('compatibility_verified',[])
        for application in spec.get('compatibility',[]):
            if application not in verified:blockers.append('Verify actual file compatibility with '+application)
        if verified:description+='\nVerified editing/viewing applications: '+', '.join(verified)
        if not spec.get('instructions'):blockers.append('Supply human-authored customer instructions')
        if is_physical(spec) and spec['provider'].get('sample_reviewed') is not True:
            blockers.append('Review a real physical sample before distribution')
        if spec['family']=='pet_portrait' and spec['product_data'].get('likeness_reviewed') is not True:
            blockers.append('Review the actual subject likeness and proof')
    return {'title':spec['name'],'description':description,'tags':tags,'price':spec['price'],
            'taxonomy_id':spec['category_id'],'blockers':blockers,'seo_score':None,'profit_validated':False,
            'demand_status':spec['research'].get('status','unvalidated_operator_concept'),
            'facts_verified_by_operator_required':True,'state':'draft',
            **({'delivery_status':'operator_handoff_required','automatic_delivery_verified':False}
               if delivery_kind(spec)=='made_to_order_digital' else {})}
