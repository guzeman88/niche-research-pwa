"""Real editable product builders. Technical success never certifies buyer usefulness."""
from pathlib import Path
from decimal import Decimal, InvalidOperation
from datetime import date
import hashlib
import json
import shutil
import zipfile

from PIL import Image
from pypdf import PdfReader
from . import office

VERSION = 'etgen-v2-masters-1'
DOCUMENTS = {'birthday_magazine', 'birthday_newspaper', 'memory_book', 'party_set', 'wedding_binder'}
PALETTE = {'ink': ('213547', '64748B', 'EDF1F4'),
           'sage': ('24463B', '547363', 'EAF1EC'), 'clay': ('603F35', '906B5E', 'F5EDE8')}


def text(value, limit=1200):
    if not isinstance(value, str) or len(value) > limit or any(ord(c) < 32 and c not in '\n\t' for c in value):
        raise ValueError('Product text is invalid or exceeds its supported length')
    return value.strip()


def _data(spec):
    value = spec.get('product_data', {})
    if not isinstance(value, dict):
        raise ValueError('Product data must be an object')
    return value


def _instructions(spec, folder):
    authored = text(spec.get('instructions', ''), 12000)
    if not authored:
        raise ValueError('Supply human-authored customer instructions before production')
    (folder / 'instructions.txt').write_text(authored, encoding='utf-8')
    (folder / 'font-license.txt').write_bytes((Path(__file__).parent / 'fonts/LICENSE.txt').read_bytes())


def _package(folder, result, spec):
    _instructions(spec, folder)
    files = list(dict.fromkeys([*result['customer_files'], 'instructions.txt', 'font-license.txt']))
    if any(name.endswith(('.pptx','.xlsx')) for name in files):
        shutil.copyfile(Path(__file__).parent/'fonts/NotoSans-Regular.ttf',folder/'NotoSans-Regular.ttf')
        files.append('NotoSans-Regular.ttf')
    with zipfile.ZipFile(folder / 'customer.zip', 'w', zipfile.ZIP_DEFLATED) as archive:
        for name in files:
            if '/' in name or '\\' in name or not (folder / name).is_file():
                raise ValueError('A promised customer file is missing or unsafe')
            info = zipfile.ZipInfo(name, date_time=(2026, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(info, (folder / name).read_bytes())
    result['customer_files'] = [*files, 'customer.zip']
    roles = result.setdefault('roles', {})
    for name in files:
        roles.setdefault(name, 'customer_editable' if name.endswith(('.pptx', '.xlsx')) else 'customer_download')
    roles['customer.zip'] = 'customer_bundle'
    for name in result['previews']:
        roles[name] = 'preview'
    result.update(template=VERSION, preview='preview.png')
    result.setdefault('preview_kind','rasterized_actual_customer_pdf')
    return result


def _textbox(slide, x, y, width, height, wording, size=16, color='213547', name=None, bold=False):
    from pptx.util import Inches, Pt
    from pptx.dml.color import RGBColor
    # Use the same bundled-font measurements as the deterministic renderer to
    # reject obvious overflow before asking the office application to render it.
    from .render import wrap
    lines = wrap(wording, width * 72 - 12, size)
    if len(lines) * size * 1.35 > height * 72 - 10:
        raise ValueError('Editable text exceeds the original master; shorten it or add a page')
    box = slide.shapes.add_textbox(Inches(x), Inches(y), Inches(width), Inches(height))
    box.name = name or 'editable-text'
    frame = box.text_frame; frame.word_wrap = True
    frame.margin_left = frame.margin_right = Inches(.04)
    frame.margin_top = frame.margin_bottom = Inches(.02)
    for i, paragraph in enumerate(wording.split('\n')):
        p = frame.paragraphs[0] if i == 0 else frame.add_paragraph()
        p.text = paragraph; p.font.name = 'Noto Sans'; p.font.size = Pt(size)
        p.font.bold = bold; p.font.color.rgb = RGBColor.from_string(color)
    return box


def _photo(slide, x, y, width, height, artwork, index):
    from pptx.util import Inches
    from pptx.enum.shapes import MSO_SHAPE
    from pptx.dml.color import RGBColor
    if artwork:
        with Image.open(artwork) as im:
            if im.width * im.height > 40_000_000:
                raise ValueError('Photo exceeds local pixel budget')
        picture = slide.shapes.add_picture(str(artwork), Inches(x), Inches(y), width=Inches(width))
        # Fit the original picture without stretching or silently cropping it.
        if picture.height > Inches(height):
            ratio = Inches(height) / picture.height
            picture.width = int(picture.width * ratio); picture.height = Inches(height)
        picture.left += int((Inches(width) - picture.width) / 2)
        picture.top += int((Inches(height) - picture.height) / 2)
        picture.name = f'replaceable-photo-{index}'
    else:
        shape = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(x), Inches(y), Inches(width), Inches(height))
        shape.name = f'photo-frame-{index}'
        shape.fill.solid(); shape.fill.fore_color.rgb = RGBColor.from_string('EDF1F4')
        shape.line.color.rgb = RGBColor.from_string('AAB9C1')
        _textbox(slide, x+.18, y+height/2-.3, width-.36, .6, 'Your photo', 15, '64748B', f'photo-label-{index}')


def build_document(spec, folder, artwork=None):
    """Public helper also supports testing editable sources before office setup."""
    from pptx import Presentation
    from pptx.util import Inches
    from pptx.enum.shapes import MSO_SHAPE
    from pptx.dml.color import RGBColor
    folder = Path(folder); folder.mkdir(parents=True, exist_ok=True)
    data = _data(spec); family = spec['family']
    recipient = text(data.get('recipient', 'Your name'), 80)
    if data.get('age') is not None and (type(data['age']) is not int or not 1 <= data['age'] <= 120):
        raise ValueError('Age must be between one and 120')
    if data.get('occasion_date'):
        text(data['occasion_date'], 80)
    pages = data.get('pages')
    if pages is None:
        pages = [{'title': text(heading, 120), 'body': ''} for heading in spec['content']]
    if not isinstance(pages, list) or not 1 <= len(pages) <= 40:
        raise ValueError('Provide between one and forty structured document pages')
    if family == 'party_set':
        # Every piece has its real advertised canvas; use a separate deck/PDF per size.
        outputs = []
        welcome_size=(8.2677,11.6929) if spec.get('size')=='a4' else (8.5,11)
        for key, label, dimensions in [('invitation', 'Invitation', (5, 7)),
                                       ('welcome', 'Welcome', welcome_size), ('gift-tags', 'Gift tags', (2, 3.5))]:
            p = Presentation(); p.slide_width = Inches(dimensions[0]); p.slide_height = Inches(dimensions[1])
            s = p.slides.add_slide(p.slide_layouts[6]); w, h = dimensions
            _textbox(s, .2, .2, w-.4, .7, label, 12, name='editable-label')
            _textbox(s, .2, h*.3, w-.4, h*.3, recipient, 20 if w > 3 else 12, name='editable-recipient')
            _textbox(s, .2, h*.7, w-.4, h*.2, text(data.get('occasion_date', 'Celebrating together'), 80), 10, name='editable-date')
            path = folder / (key+'.pptx'); p.save(path); outputs.append(path)
        return outputs
    p = Presentation(); p.slide_width = Inches(8.5 if spec.get('size') != 'a4' else 8.2677)
    p.slide_height = Inches(11 if spec.get('size') != 'a4' else 11.6929)
    width, height = p.slide_width / Inches(1), p.slide_height / Inches(1)
    ink, accent, tint = PALETTE[spec.get('palette', 'ink')]
    cover = p.slides.add_slide(p.slide_layouts[6])
    bar = cover.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(.5), Inches(.6), Inches(width-1), Inches(.12))
    bar.fill.solid(); bar.fill.fore_color.rgb = RGBColor.from_string(accent); bar.line.fill.background()
    _textbox(cover, .6, 1, width-1.2, 1.8, text(spec['name'], 120), 28, ink, 'editable-cover-title', True)
    _textbox(cover, .6, 2.8, width-1.2, .8, recipient, 20, accent, 'editable-recipient')
    _photo(cover, .65, 4, width-1.3, height-5.1, artwork, 0)
    for index, page in enumerate(pages, 1):
        if not isinstance(page, dict):
            raise ValueError('Each document page requires title and body fields')
        heading = text(page.get('title', ''), 120); body = text(page.get('body', ''), 2200)
        slide = p.slides.add_slide(p.slide_layouts[6])
        _textbox(slide, .6, .5, width-1.2, .5, f'{index:02d}  /  {recipient}', 10, accent, f'editable-running-title-{index}')
        _textbox(slide, .6, 1.2, width-1.2, 1.3, heading, 26, ink, f'editable-heading-{index}', True)
        if family == 'birthday_newspaper':
            # Original two-column editorial master with separately editable paragraphs.
            chunks = body.split('\n\n', 1)
            _textbox(slide, .6, 2.7, (width-1.5)/2, height-3.6, chunks[0], 13, ink, f'editable-column-a-{index}')
            _textbox(slide, (width+.3)/2, 2.7, (width-1.5)/2, height-3.6, chunks[1] if len(chunks)>1 else '', 13, ink, f'editable-column-b-{index}')
        elif family == 'wedding_binder':
            _textbox(slide, .6, 2.7, width-1.2, height-3.5, body, 14, ink, f'editable-binder-content-{index}')
        elif family=='memory_book':
            _photo(slide,.6,2.8,(width-1.45)/2,3.6,artwork,index*2)
            _photo(slide,(width+.25)/2,2.8,(width-1.45)/2,3.6,artwork,index*2+1)
            _textbox(slide,.6,6.8,width-1.2,height-7.5,body,14,ink,f'editable-memory-caption-{index}')
        else:
            _photo(slide, .6, 2.8, width-1.2, 3.6, artwork, index)
            _textbox(slide, .6, 6.8, width-1.2, height-7.5, body, 14, ink, f'editable-story-{index}')
        _textbox(slide, .6, height-.5, width-1.2, .4, str(index), 9, accent, f'page-number-{index}')
    path = folder / 'customer.pptx'; p.save(path)
    return [path]


def _money(value):
    try:
        amount = Decimal(str(value or 0))
    except InvalidOperation as exc:
        raise ValueError('Money must be a finite decimal amount') from exc
    if not amount.is_finite() or abs(amount) > 100_000_000 or amount.as_tuple().exponent < -2:
        raise ValueError('Money must use at most two decimal places within supported bounds')
    return amount


def workbook_expectations(data):
    rows = data.get('budget', [])
    totals = {'estimated': Decimal(0), 'actual': Decimal(0), 'paid': Decimal(0), 'outstanding': Decimal(0)}
    for row in rows:
        for key in ('estimated', 'actual', 'paid'):
            totals[key] += _money(row.get(key))
        totals['outstanding'] += max(Decimal(0), _money(row.get('actual'))-_money(row.get('paid')))
    return {**{k: float(v) for k, v in totals.items()},
            'attending': sum(r.get('rsvp') == 'Yes' for r in data.get('guests', []))}


def _cell_text(value, limit=300):
    value = text(value or '', limit)
    if value.startswith(('=', '+', '-', '@')):
        value = "'" + value
    return value


def build_workbook(spec, folder):
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Protection, Alignment
    from openpyxl.worksheet.datavalidation import DataValidation
    from openpyxl.workbook.properties import CalcProperties
    data = _data(spec); capacity = data.get('capacity', 100)
    if type(capacity) is not int or not 10 <= capacity <= 1000:
        raise ValueError('Workbook capacity must be ten to one thousand rows')
    for collection in ('budget', 'guests', 'vendors'):
        if not isinstance(data.get(collection, []), list) or len(data.get(collection, [])) > capacity:
            raise ValueError('Workbook inputs exceed their supported row capacity')
        if any(not isinstance(row,dict) for row in data.get(collection, [])):
            raise ValueError('Each workbook row must be a structured record')
    if data.get('event_date'):
        try: date.fromisoformat(data['event_date'])
        except (TypeError, ValueError) as exc: raise ValueError('Event date must be an ISO date') from exc
    expected = workbook_expectations(data)
    wb = Workbook(); config = wb.active; config.title = 'Overview'
    wb.calculation = CalcProperties(calcId=191029, fullCalcOnLoad=True)
    end = capacity+1
    for name, headers in [('Budget', ['Category', 'Item', 'Estimated', 'Actual', 'Paid', 'Outstanding', 'Variance']),
                          ('Guests', ['Household', 'Name', 'RSVP', 'Meal', 'Notes']),
                          ('Vendors', ['Name', 'Service', 'Contact', 'Notes']),
                          ('Timeline', ['Date', 'Time', 'Activity', 'Owner', 'Contact'])]:
        ws = wb.create_sheet(name); ws.append(headers); ws.freeze_panes = 'A2'
        ws.auto_filter.ref = f'A1:{chr(64+len(headers))}{end}'
        for row in ws.iter_rows(min_row=2, max_row=end, max_col=len(headers)):
            for cell in row:
                cell.protection = Protection(locked=False)
                cell.font=Font(name='Noto Sans',size=11,color='213547')
                cell.alignment=Alignment(vertical='top',wrap_text=True)
        for cell in ws[1]:
            cell.font = Font(name='Noto Sans', bold=True, color='FFFFFF')
            cell.fill = PatternFill('solid', fgColor='24463B')
        for column in range(1, len(headers)+1): ws.column_dimensions[chr(64+column)].width = 23
        ws.print_title_rows = '1:1'; ws.sheet_properties.pageSetUpPr.fitToPage = True
        ws.page_setup.orientation = 'landscape'; ws.page_setup.paperSize = ws.PAPERSIZE_A4
        ws.page_setup.fitToWidth = 1; ws.page_setup.fitToHeight = 0
        ws.print_options.horizontalCentered = True
        # Blank customer templates print useful working rows, not hundreds of empty pages.
        ws.print_area = f'A1:{chr(64+len(headers))}{min(end, max(16, len(data.get(name.lower(), []))+2))}'
    budget = wb['Budget']
    budget.protection.sheet=True
    for i in range(2, end+1):
        budget.cell(i,6,f'=IF(COUNTA(B{i}:E{i})=0,"",MAX(0,D{i}-E{i}))')
        budget.cell(i,7,f'=IF(COUNTA(C{i}:D{i})=0,"",D{i}-C{i})')
        for j in range(3,8): budget.cell(i,j).number_format = '#,##0.00;[Red]-#,##0.00'
        for j in (6,7): budget.cell(i,j).protection = Protection(locked=True)
    for i, row in enumerate(data.get('budget', []), 2):
        budget.cell(i,1,_cell_text(row.get('category'))); budget.cell(i,2,_cell_text(row.get('item')))
        for j,key in enumerate(('estimated','actual','paid'),3): budget.cell(i,j,float(_money(row.get(key))))
    for i,row in enumerate(data.get('guests', []),2):
        rsvp = row.get('rsvp','Pending')
        if rsvp not in ('Pending','Yes','No'): raise ValueError('RSVP must be Pending, Yes or No')
        for j,key in enumerate(('household','name','rsvp','meal','notes'),1): wb['Guests'].cell(i,j,_cell_text(row.get(key, rsvp if key=='rsvp' else '')))
    for i,row in enumerate(data.get('vendors', []),2):
        for j,key in enumerate(('name','service','contact','notes'),1): wb['Vendors'].cell(i,j,_cell_text(row.get(key)))
    validation = DataValidation(type='list', formula1='"Pending,Yes,No"', allow_blank=True)
    validation.errorTitle='Choose a supported RSVP'; validation.error='Use Pending, Yes or No'; validation.showErrorMessage=True
    wb['Guests'].add_data_validation(validation); validation.add(f'C2:C{end}')
    config.append(['Wedding planning overview','Value']); config.append(['Currency',_cell_text(data.get('currency','USD'),8)])
    config.append(['Event date',_cell_text(data.get('event_date',''),20)]); config.append(['Supported rows',capacity])
    metrics = [('Estimated',f'=SUM(Budget!C2:C{end})'),('Actual',f'=SUM(Budget!D2:D{end})'),
               ('Paid',f'=SUM(Budget!E2:E{end})'),('Outstanding',f'=SUM(Budget!F2:F{end})'),
               ('Attending',f'=COUNTIF(Guests!C2:C{end},"Yes")')]
    for label,formula in metrics: config.append([label,formula])
    config.column_dimensions['A'].width=32; config.column_dimensions['B'].width=28
    config.freeze_panes='B2'; config.print_area='A1:B9'
    for cell in config[1]: cell.font=Font(bold=True,color='FFFFFF'); cell.fill=PatternFill('solid',fgColor='24463B')
    config.append(['Instructions', 'See the supplied human-authored instructions.txt.'])
    folder=Path(folder);folder.mkdir(parents=True,exist_ok=True)
    path=folder/'customer.xlsx';wb.save(path)
    (folder/'calculation-expectations.json').write_text(json.dumps(expected,sort_keys=True),encoding='utf-8')
    return path


def _editable(spec, folder, artwork):
    family=spec['family']; customer=[]; all_pdf=[]
    if family=='wedding_workbook':
        source=build_workbook(spec,folder)
        recalculated=office.convert(source,folder/'recalculated','xlsx')
        shutil.copyfile(recalculated,source)
        calculated=check_calculations(source,_data(spec))
        if not all(c['passed'] for c in calculated): raise ValueError('Actual spreadsheet recalculation did not match expected arithmetic')
        pdf=office.convert(source,folder/'converted')
        shutil.copyfile(pdf,folder/'customer.pdf');customer=['customer.xlsx','customer.pdf'];all_pdf=[folder/'customer.pdf']
    else:
        for source in build_document(spec,folder,artwork):
            pdf=office.convert(source,folder/'converted')
            target=folder/(source.stem+'.pdf');shutil.copyfile(pdf,target)
            customer.extend([source.name,target.name]);all_pdf.append(target)
    from pypdf import PdfWriter
    if len(all_pdf)>1:
        writer=PdfWriter()
        for pdf in all_pdf: writer.append(str(pdf))
        writer.write(folder/'collection-review.pdf');preview_pdf=folder/'collection-review.pdf'
    else: preview_pdf=all_pdf[0]
    names=office.previews(preview_pdf,folder)
    return {'customer_files':customer,'masters':[],'previews':names,'pages':len(names),
            'roles':{'calculation-expectations.json':'internal_check'} if family=='wedding_workbook' else {},
            'compatibility_verified':['LibreOffice', 'LibreOffice Calc' if family=='wedding_workbook' else 'LibreOffice Impress', 'PDF reader'],
            'readiness':{'editable_files':'generated','office_roundtrip':'passed','manufacturing':'not_applicable'}}


def check_calculations(path,data):
    from openpyxl import load_workbook
    expected=workbook_expectations(data); wb=load_workbook(path,data_only=True)
    checks=[]
    for row,key in [(5,'estimated'),(6,'actual'),(7,'paid'),(8,'outstanding'),(9,'attending')]:
        actual=wb['Overview'].cell(row,2).value
        valid=isinstance(actual,(int,float)) and abs(float(actual)-expected[key])<.005
        checks.append({'check':'recalculated_'+key,'passed':valid})
    return checks


def _pdf_from_authored(spec,folder,artwork):
    from .render import Page, font_register
    from reportlab.pdfgen.canvas import Canvas
    font_register(); data=_data(spec); family=spec['family']; pages=[]
    if family=='pet_portrait':
        if not artwork or not data.get('likeness_reviewed'):
            raise ValueError('Pet portraits require actual original artwork and an individual likeness review')
        if spec.get('size') not in ('8x10','12x16'):
            raise ValueError('Digital pet portraits require an explicit 8x10 or 12x16 print size')
        width,height={'8x10':(576,720),'12x16':(864,1152)}[spec['size']]
        p=Page(width,height);p.image(artwork,width*.065,height*.05,width*.87,height*.75)
        p.text(width*.07,height*.835,text(data.get('pet_name',''),80),24,width=width*.86,max_lines=2)
        p.text(width*.07,height*.92,text(data.get('date',''),60),12,width=width*.86,max_lines=1);pages=[p]
    else:
        report=data.get('maker_test',{})
        if not text(data.get('author',''),120) or not text(data.get('tested_revision',''),120):
            raise ValueError('Record the human pattern author and exact tested instruction revision')
        if not isinstance(report,dict) or not all(text(report.get(k,''),2000) for k in ('tester','completed_at','notes')) or not artwork:
            raise ValueError('A maker test report and original finished-object photograph are required')
        instructions=data.get('instructions',[]);materials=data.get('materials',[])
        if not isinstance(instructions,list) or not instructions or len(instructions)>80 or not materials:
            raise ValueError('Supply the actual human-authored pattern instructions and materials')
        for record in data.get('rounds',[]):
            if not isinstance(record,dict) or type(record.get('number')) is not int or type(record.get('stitches')) is not int or record['stitches']<0:
                raise ValueError('Pattern round structure is invalid')
            if 'repeats' in record and (type(record['repeats']) is not int or record['repeats']<1): raise ValueError('Pattern repeat count is invalid')
            if all(k in record for k in ('start_count','increases','decreases')):
                if any(type(record[k]) is not int or record[k]<0 for k in ('start_count','increases','decreases')) or record['start_count']+record['increases']-record['decreases']!=record['stitches']:
                    raise ValueError('Authored round stitch arithmetic is inconsistent')
        width,height=(595.28,841.89) if spec.get('size')=='a4' else (612,792)
        cover=Page(width,height);cover.text(44,36,text(spec['name'],120),24,width=width-88,max_lines=3)
        cover.image(artwork,44,150,width-88,400);cover.text(44,590,'By '+data['author'],14,width=width-88,max_lines=2)
        pages=[cover]
        sections=[('Materials','\n'.join(text(v,300) for v in materials)),*[(f'Instructions {i+1}',text(v,2200)) for i,v in enumerate(instructions)]]
        if data.get('gauge') or data.get('dimensions'):
            sections.insert(1,('Maker measurements','Gauge: '+text(data.get('gauge','Not supplied'),500)+'\nFinished dimensions: '+text(data.get('dimensions','Not supplied'),500)))
        if data.get('rounds'):
            sections.append(('Authored round counts','\n'.join(f"Round {r['number']}: {r['stitches']} stitches"+(f"; {r['repeats']} repeats" if r.get('repeats') else '') for r in data['rounds'])))
        for title,body in sections:
            p=Page(width,height);p.text(44,36,title,20,width=width-88,max_lines=2)
            p.text(44,110,body,12,width=width-88,max_lines=35);pages.append(p)
        chart=data.get('chart',[])
        if not isinstance(chart,list) or len(chart)>40:
            raise ValueError('An authored stitch chart supports at most forty rows')
        if chart:
            if any(not isinstance(row,list) or not 1<=len(row)<=24 for row in chart):
                raise ValueError('An authored chart row supports one to twenty-four cells')
            p=Page(width,height);p.text(44,36,'Maker-authored stitch chart',20,width=width-88,max_lines=2)
            for row_index,row in enumerate(chart):
                for col_index,symbol in enumerate(row):
                    if symbol not in ('sc','dc','ch','inc','dec','slst','.'):
                        raise ValueError('Use documented chart symbols: sc, dc, ch, inc, dec, slst or .')
                    x=44+col_index*21;y=100+row_index*15
                    p.rect(x,y,20,14,'#EDF1F4');p.text(x+2,y+2,symbol,7,width=19,max_lines=1)
            pages.append(p)
        source_hash=pattern_source_fingerprint(data)
        (folder/'maker-evidence.json').write_text(json.dumps({'author':data['author'],'tested_revision':data['tested_revision'],'source_fingerprint':source_hash,'maker_test':report},indent=2),encoding='utf-8')
    canvas=Canvas(str(folder/'customer.pdf'),pagesize=(pages[0].width,pages[0].height),invariant=1)
    for page in pages:page.pdf(canvas);canvas.showPage()
    canvas.save();names=office.previews(folder/'customer.pdf',folder)
    return {'customer_files':['customer.pdf'],'masters':[],'previews':names,'pages':len(pages),
            'compatibility_verified':['PDF reader'],
            'roles':{'maker-evidence.json':'internal_evidence'} if family=='crochet_pattern' else {},
            'blockers':(['Bind the maker test to the current authored source fingerprint'] if family=='crochet_pattern' and report.get('source_fingerprint')!=source_hash else []),
            'readiness':{'likeness':'human_reviewed' if family=='pet_portrait' else 'not_applicable',
                         'maker_test':('reported_requires_final_review' if report.get('source_fingerprint')==source_hash else 'source_unbound') if family=='crochet_pattern' else 'not_applicable'}}


def pattern_source_fingerprint(data):
    """The maker signs this exact source identity after a real independent make."""
    payload={key:data.get(key,[] if key in ('instructions','materials','rounds','chart') else '')
             for key in ('author','tested_revision','instructions','materials','rounds','chart','gauge','dimensions')}
    return hashlib.sha256(json.dumps(payload,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()


def _bundle(spec,folder):
    sources=spec.get('_component_sources')
    if not sources or not isinstance(sources,list) or len(sources)>20:
        raise ValueError('Bundles require engine-resolved approved component revisions')
    customer=[];components=[];pdfs=[]
    for index,source in enumerate(sources,1):
        components.append({k:source[k] for k in ('job_id','revision','artifact_fingerprint')})
        for item in source['files']:
            if item['name']=='customer.zip':continue
            name=f'{index:02d}-'+Path(item['name']).name
            if not Path(item['path']).is_file():raise ValueError('A pinned bundle component is missing')
            shutil.copyfile(item['path'],folder/name);customer.append(name)
            if name.endswith('.pdf'):pdfs.append(folder/name)
    if not pdfs: raise ValueError('Bundle requires actual component PDF previews')
    from pypdf import PdfWriter
    writer=PdfWriter()
    for p in pdfs:writer.append(str(p))
    writer.write(folder/'bundle-review.pdf')
    names=office.previews(folder/'bundle-review.pdf',folder)
    (folder/'components.json').write_text(json.dumps(components,indent=2),encoding='utf-8')
    return {'customer_files':customer,'masters':[],'previews':names,'pages':len(names),
            'compatibility_verified':['LibreOffice','PDF reader'],
            'roles':{'components.json':'internal_dependencies'},'components':components}


def render_v2(spec,folder,artwork=None):
    folder=Path(folder);folder.mkdir(parents=True,exist_ok=True);family=spec['family']
    if family in DOCUMENTS or family=='wedding_workbook':result=_editable(spec,folder,artwork)
    elif family=='pet_portrait' and spec.get('delivery_kind')=='physical':
        if not artwork or not _data(spec).get('likeness_reviewed'):
            raise ValueError('Physical portraits require original artwork and individual likeness review')
        from .render import render as legacy
        mapped={**spec,'family':'apparel','size':'provider'}
        result=legacy(mapped,folder,artwork);result['previews']=['preview.png']
        result['roles']={'editable-master.svg':'internal_master'}
        result['compatibility_verified']=['PNG artwork']
        result['readiness']={'manufacturing':'not_verified','likeness':'human_reviewed'}
    elif family in ('pet_portrait','crochet_pattern'):result=_pdf_from_authored(spec,folder,artwork)
    elif family=='bundle':result=_bundle(spec,folder)
    elif family=='tote':
        from .render import render as legacy
        mapped={**spec,'family':'apparel','size':'provider'}
        result=legacy(mapped,folder,artwork);result['previews']=['preview.png']
        # Legacy SVG omits raster artwork: keep it explicitly internal, never sell as editable.
        result['roles']={'editable-master.svg':'internal_master'}
        result['compatibility_verified']=['PNG artwork']
        result['readiness']={'manufacturing':'not_verified'}
    else:raise ValueError('No specialized builder is available for this family')
    return _package(folder,result,spec)


def inspect_v2(folder,result,spec):
    folder=Path(folder);checks=[];family=spec['family']
    for name in result.get('customer_files',[]):
        path=folder/name
        if name.endswith('.pptx'):
            from pptx import Presentation
            deck=Presentation(path)
            checks.append({'check':'editable_source_'+name,'passed':len(deck.slides)>0 and any(sh.has_text_frame for slide in deck.slides for sh in slide.shapes)})
        if name.endswith('.xlsx'):
            from openpyxl import load_workbook
            book=load_workbook(path,data_only=False)
            checks.append({'check':'formula_source_'+name,'passed':not book._external_links and bool(book['Overview']['B5'].data_type=='f')})
            if family=='wedding_workbook':checks.extend(check_calculations(path,_data(spec)))
        if name.endswith('.pdf'):
            document=PdfReader(path)
            checks.append({'check':'actual_pdf_'+name,'passed':len(document.pages)>0 and all(float(p.mediabox.width)>0 for p in document.pages)})
            if family in DOCUMENTS or family=='wedding_workbook':
                fonts=[str(font.get_object().get('/BaseFont','')) for page in document.pages for font in page.get('/Resources',{}).get('/Font',{}).get_object().values()]
                checks.append({'check':'bundled_font_'+name,'passed':any('NotoSans' in font.replace('-','') for font in fonts)})
    for name in result.get('previews',[]):
        with Image.open(folder/name) as image:image.verify()
        checks.append({'check':'actual_preview_'+name,'passed':True})
    if family=='tote':
        with Image.open(folder/'artwork.png') as image:
            checks.append({'check':'provider_dimensions','passed':image.size==(spec['provider']['width_px'],spec['provider']['height_px'])})
    return {'checks':checks,'readiness':result.get('readiness',{}),'blockers':result.get('blockers',[])}
